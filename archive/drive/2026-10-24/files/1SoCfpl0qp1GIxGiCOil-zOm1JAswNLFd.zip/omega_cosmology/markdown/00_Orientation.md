# Omega Cosmology: a primer

## 00 — Orientation

Omega Cosmology studies the structure of continuation: how physical situations support, constrain, differentiate, and transform what can follow from them. Its central object is the full structure of consequential possibility. Its practical concern is how processes within that structure—including agents and valuers—alter the conditions of their own and others' continuation.

The program begins with physics, develops a language for perspective and consequence, and uses that language to investigate value and agency. Gradient Ethics is its ethical branch. Omega Decision Theory supplies an architecture for decisions under incomplete knowledge. Awareness and theology enter as interpretations and further questions about the same structure.

The guiding intuition is simple. An action does more than select an immediate outcome. It changes the future conditions under which further outcomes, actions, relationships, discoveries, and valuations become possible. A destroyed library, a repaired ecosystem, a new mathematical language, and a self-modifying machine alter this structure in different ways. Understanding those differences requires more than counting immediate results.

## The structure-first move

The framework adopts a completed description as its organizing viewpoint. Events, records, correlations, and continuations belong to one physical object. A situated process encounters only part of that object, from a particular physical relationship to it. The resulting description is perspectival without being arbitrary: physical coupling, causal access, records, and available interactions constrain it.

“Completed” describes the viewpoint. It does not give a finite observer complete knowledge or imply a single classical trajectory. In a quantum realization, interference, entanglement, and incompatible possible measurements belong to the object. A block-Everett interpretation is a natural home for this picture, while much of the operational work can proceed without settling between interpretations of quantum mechanics.

The program repeatedly makes three moves:

1. Replace isolated objects with the relations and continuation processes that sustain them.
2. Replace raw multiplicity with physically differentiated consequential structure.
3. Distinguish what the full object contains from what a bounded model can represent.

These moves connect the physics to the ethics. A convenient proxy can help an agent act, but it cannot redefine the reality against which that action should be assessed.

## The main terms

A **perspective** is a physically situated continuation process. It need not be conscious, intentional, or alive. A **focus** specifies a condition or boundary relation through which compatible quantum contributions are organized. **Consequence** is a difference in continuation. The **futures field** is the structured physical possibility of such continuation; “field” is a conceptual name, not an assertion that it is an additional field in quantum field theory.

**Lushness** is the proposed richness of value-capable possibility in this structure. Physical consequence geometry supplies candidate descriptions; whether they capture that richness is part of the research. **Valuers** are provisionally understood as processes for which distinctions matter endogenously. A **deformer** makes a difference to continuation without thereby being a valuer. **Gradient Ethics** investigates how policies preserve, develop, capture, or foreclose the conditions through which valuation can occur.

The foundational dependence claim is that value requires valuers. Value itself remains open; its possibility in the substrate is the present proxy. GE adopts consideration for that possibility under uncertainty and investigates how rights-like protections, justice, cooperation, and defensive capability serve it. This does not make every instance of persistence good or require every individual continuation to be preserved. The stronger research question is whether the complete structure can explain value itself as well as its enabling conditions.

## How to read the packet

Read Parts 01–05 for the physical and mathematical spine. Parts 06–10 develop identity, recovery, agency, Gradient Ethics, and Omega Decision Theory. Parts 11–12 cover awareness and the metaphysical horizon. Part 13 supplies concrete examples; Part 14 collects the formal core. Parts 15–17 are the glossary, research program, and references.

A reader primarily interested in alignment can read this orientation, Parts 05 and 07–10, then return to the physical foundations. A technical collaborator should also read the worked examples and formal core before designing experiments. An LLM ingesting the packet should use the complete edition and keep the distinction between definitions, hypotheses, and results intact.

## How claims are presented

Established mathematical tools retain their established meaning. Framework definitions introduce the program's vocabulary. Hypotheses identify proposed connections to be investigated. Explicit propositions in the formal core have short derivations and stated domains. Open work is collected in Part 16 rather than repeated as a disclaimer throughout the text.

The program's contribution is the assembled research question and its discipline of consequence-preserving description. Quantum mechanics supplies a substantial backbone; it does not by itself establish a universal measure of lushness, a theory of consciousness, or an ethical ordering. The primer shows how to work on those questions without confusing them.

The ambition is a coherent account that extends from elementary continuation to the conditions of value. The immediate task is concrete: identify what must be retained when describing how a physical difference changes what can follow.
