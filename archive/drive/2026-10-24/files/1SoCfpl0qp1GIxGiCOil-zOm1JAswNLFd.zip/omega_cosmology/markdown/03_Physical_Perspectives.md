# 03 — Physical perspectives and relative presents

## Perspective as situated continuation

A physical perspective is a process described from a situated interface with the rest of reality. Its specification includes where and how it couples, which degrees of freedom belong to the description, what correlations cross its boundary, and how continuation is organized there.

This is broader than observation by a mind. A photon interacting with a detector, a gas exchanging energy with its surroundings, a crystal carrying an excitation, and a civilization building instruments all have physically situated continuation. Agency and awareness are additional forms of organization within this domain.

The perspective is not a freely floating viewpoint added to the world. Its boundary and continuation must be physically supported. Different decompositions may be legitimate for different purposes; the program seeks their consistent relationships rather than a unique partition of reality into subjects.

## A useful specification

For concrete work, write a perspective specification schematically as:

```text
P = (region or interface, observable algebra,
     boundary condition, coupling structure, continuation domain).
```

The list is a modeling interface, not a proposed new elementary particle. In finite quantum examples, the algebra may be all operators on a subsystem Hilbert space. In field-theoretic work it may be a local algebra associated with a spacetime region. The continuation domain identifies which interactions and extensions are physically at issue.

Subsystem structure itself deserves attention. Accessible observables can help identify a useful tensor-product decomposition, while different physical couplings can support different decompositions. This is one reason “the same thing from another perspective” needs a transformation rule rather than an intuitive assertion. [R13]

Quantum reference frames and relational quantum mechanics offer complementary precedents. The former provides explicit transformations in particular models; the latter emphasizes the relational character of state attribution. Neither is simply adopted wholesale as the definition of Omega perspective. [R02, R03, R14]

## Relative present and focus

A relative present specifies a boundary for describing a process. Focus specifies a condition through which connections across or away from that boundary are resolved. They interact, but they answer different questions.

For example, a field state may be described on a spacelike hypersurface, while a detector effect specifies a focus in a later region. Changing the hypersurface requires the appropriate dynamical and geometric transformation. Changing the detector effect changes the conditional question. Their relation can be studied in the same model without identifying a basis choice with a tilt of spacetime.

The present membrane can therefore be a valuable organizing image: compatible correlations pass through a situated boundary. It should retain the mathematical structure of that boundary rather than suggest an impermeable surface separating a fixed classical past from an unstructured future.

## Memory and the full process

Physical memory is dependence carried by the present organization of a system and its correlations. A durable register is one familiar architecture, but even a temporary environment correlation can carry memory into later behavior.

A full relevant joint state and dynamics can encode this dependence at one boundary. When access is restricted to a subsystem across several times, a process tensor represents how the subsystem responds to sequences of operations. It is a compact operational description of multi-time structure, including environmental memory. [R15, R16]

Thus “the present contains the relevant past” and “a local description needs multi-time information” can both be true. The first concerns a sufficient physical boundary description. The second concerns a reduced description whose local instantaneous state omits consequential correlations.

Exhausting tester families is a way to characterize that process: consider every admissible sequence of interactions on the specified interface. The tester family is determined by the physical setting being studied. Restricting it for a calculation produces an approximation, not a new universe in which omitted distinctions cease to exist.

## Composition and scale

Two perspectives can overlap, share records, exchange signals, or be combined into a larger process. Their combination must retain joint correlations. Taking a product of their reduced descriptions is valid only where the required independence holds.

Higher-level perspectives become useful when stable organization supports repeatable continuation: molecules, cells, organisms, institutions. The same broad relational move applies at these scales, while the relevant mathematics and effective variables can change.

Massive worldlines admit proper-time descriptions. Massless propagation follows null structure and has no rest frame in which an ordinary observer can sit. Both participate in causal dependencies. Momentum, polarization, helicity, and other physical structures provide further orientations without requiring an additional hidden time dimension. [R17, R18]

The open task is to make these perspective specifications interoperable: to show which continuation distinctions survive when one description is transformed, composed, or compressed into another.

Further reading: subsystem structure [R13]; relational quantum mechanics [R14]; process tensors [R15, R16]; relativistic geometry and particle representations [R17, R18].
