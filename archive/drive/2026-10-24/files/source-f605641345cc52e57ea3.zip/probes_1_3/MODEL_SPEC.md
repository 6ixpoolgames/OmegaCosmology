# Probes 1–3: model specification

## Scope and question

These are finite structural diagnostics, not simulated societies or ethical reward environments. They ask which information candidate lushness summaries retain, which preferences calibration permits, and how probability changes a comparison at fixed nonzero support.

All probabilities and finite moments are rational and calculated exactly. Logarithms, charts, and dense plotting grids use floating point. The substantive boundaries below are analytic. There is no Monte Carlo sampling, fitted model, training, or GPU use.

The models are classical preparations and readout processes. Each finite law P can be embedded as the diagonal density matrix rho = sum_x P(x)|x><x|, with readouts in that basis. This is a special case of the primer's quantum machinery, not a test of interference or a derivation of a quantum theory of value. No probability distribution over counterfactual policies is introduced.

## Probe 1: dependence hidden from covariance

Three sequentially readable binary records X,Y,Z take values in {-1,+1}. Fix

    P_t(x,y,z) = (1 + t*x*y*z)/8, -1 <= t <= 1.

A realization draws independent fair X and Y, then sets Z=BXY, where B is independent and P(B=+1)=(1+t)/2. Retain the full joint law. The examples t=-1,-1/2,0,1/2,1 are exactly enumerated.

Compare means, all pair marginals, covariance, support, entropy, conditional entropy H(Z|X,Y), parity readout, and optimal prediction of Z after X,Y. The latter quantities are operational diagnostics, not supplied value rewards.

The hypothesis under examination is covariance sufficiency for continuation information. It is not a hypothesis that every different joint distribution must have a different richness score. Equal scalar richness can be appropriate for distinct processes; the limitation is that covariance alone cannot recover an operational dependency that a later composition may use.

## Probe 2: calibration and winning regions

Use one fixed finite record alphabet containing the union of these supports and two fixed numerical readouts:

- C: equal probabilities on (+2,0),(-2,0), hence covariance diag(4,0).
- D: equal probabilities on the four points (+/-1,+/-1), hence covariance diag(1,1).
- E: equal probabilities on the four points (+/-1,+/-1/2), hence covariance diag(1,1/4).

These are explicit record preparations, not agent types. The unequal spreads are intentional; no equality of physical energy or preparation cost is asserted. This tests a candidate comparison, not resource efficiency.

For beta>0 and M=diag(1,q), q>0, use

    L(beta,M,Sigma) = ln det(I + beta Sigma M).

This equals the log determinant of I + beta M^(1/2) Sigma M^(1/2). M supplies a positive feature metric, with units chosen to make beta Sigma M dimensionless. It is a modeling input, not a parameter identified by physics in this experiment.

The determinant polynomials are

    C: 1+4 beta
    D: (1+beta)(1+q beta)
    E: (1+beta)(1+q beta/4).

Compute the winning regions and ties. Varying q while holding the recorded process fixed changes the candidate evaluation. Changing coordinates x'=Sx requires transporting the metric M'=S^(-T) M S^(-1). Keeping M numerically fixed after an unequal rescaling changes the evaluation; it is not merely another description of the same calculation.

Also check state relabeling, orthogonal feature changes, and two implementations related by an explicit bijection of their complete record states. The latter is an equivalence check, not a substantive comparison of real centralized and distributed organizations.

## Probe 3: rare broad continuation

There is a narrow record 0 and m distinguishable broad records 1,...,m. A physical flag selects the broad continuation with probability p, and its conditional readout is uniform:

    P(0)=1-p; P(i)=p/m for i=1,...,m.

At each fixed m, the same alphabet and readout remain available as p varies. These are orthogonal classical record states with full-readout operational distance one between distinct states. For 0<=epsilon<1, their covering number equals the number of positive-weight records. At epsilon>=1 the covering number is one, using closed balls centered in the retained state set.

For the covariance candidate, use the explicit, fixed feature map phi(0)=0, phi(i)=e_i in R^m. Thus every feature has norm at most one. This is a declared calibration, not a canonical physical coordinate system.

The covariance is

    Sigma = (p/m) I - (p^2/m^2) 11^T.

Its eigenvalues are p/m, multiplicity m-1, and p(1-p)/m, multiplicity one. Probe beta=1 in the displayed comparisons; retain the formula for general positive beta.

Compare support, log support, Shannon entropy in bits, covariance log determinant in nats, total variation from the narrow preparation, and the conditional broad score. Do not compare numerical magnitudes across these different metrics as though they shared a value unit.

Use m=4,16,64. Increasing m changes the physical record capacity of the model; it is a dimension stress test, not a resource-matched ethical comparison. At fixed m, support remains m+1 for every 0<p<1. Endpoint support is one at p=0 and m at p=1.

## Failure and interpretation rules

- A failed invariance is a representation problem, not evidence about ethics.
- Different scores or a score collision do not by themselves establish a value ranking.
- A tunable parameter that changes the winner is a remaining calibration debt unless the framework supplies an independent justification.
- Ignoring a low-probability event in a bounded approximation does not make it absent from the global object.
- The probability bound from the unit-norm features is conditional on that calibration. It does not bound all possible value or solve unbounded-stakes decisions.

The examples are deliberately constructed diagnostic witnesses, not a random or representative sample of the universe. They apply the current candidates to known mathematical distinctions; no novelty claim is made for the underlying probability facts.
