#!/usr/bin/env python3
"""Exact finite diagnostics with numerical logarithms and visualization.

Run: python run_probes.py --out results
Dependencies: numpy, matplotlib. No network or random sampling.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import time

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


CHECKS = []


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def moments(law):
    check('normalized nonnegative finite law', sum(law.values()) == 1 and all(p >= 0 for p in law.values()))
    d = len(next(iter(law)))
    mu = [sum(p * x[i] for x, p in law.items()) for i in range(d)]
    cov = [[sum(p * (x[i]-mu[i]) * (x[j]-mu[j]) for x,p in law.items())
            for j in range(d)] for i in range(d)]
    return mu, cov


def marginal(law, indices):
    result = {}
    for x,p in law.items():
        key = tuple(x[i] for i in indices)
        result[key] = result.get(key, F(0)) + p
    return result


def entropy(law):
    return -sum(float(p)*math.log2(float(p)) for p in law.values() if p)


def tv(a, b):
    return sum(abs(a.get(x,F(0))-b.get(x,F(0))) for x in a.keys()|b.keys())/2


def encode(value):
    if isinstance(value,F):
        return str(value)
    if isinstance(value,dict):
        if value and all(isinstance(k,tuple) for k in value):
            return [{'record':encode(k),'probability':encode(v)} for k,v in value.items()]
        return {str(k):encode(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):
        return [encode(v) for v in value]
    if isinstance(value,np.generic):
        return value.item()
    return value


def score(cov, beta=1.0, metric=None):
    cov = np.asarray(cov,dtype=float)
    metric = np.eye(cov.shape[0]) if metric is None else np.asarray(metric,dtype=float)
    # If metric=R R^T, R^T cov R is PSD and has the desired determinant.
    r = np.linalg.cholesky(metric)
    eig = np.linalg.eigvalsh(r.T @ cov @ r)
    if eig.min() < -1e-10:
        raise ValueError('Non-positive covariance')
    return float(np.log1p(beta*np.maximum(eig,0)).sum())


def probe_one():
    states = list(itertools.product((-1,1),repeat=3))
    identity = [[F(int(i==j)) for j in range(3)] for i in range(3)]
    rows, laws = [], {}
    for t in map(F,[-1,F(-1,2),0,F(1,2),1]):
        law = {x:(1+t*x[0]*x[1]*x[2])/8 for x in states}
        laws[t] = law
        mu,cov = moments(law)
        check(f'P1 covariance is identity t={t}',mu==[0,0,0] and cov==identity)
        for pair in itertools.combinations(range(3),2):
            check(f'P1 uniform pair t={t} pair={pair}',all(p==F(1,4) for p in marginal(law,pair).values()))
        p_parity = sum(p for x,p in law.items() if x[0]*x[1]*x[2]==1)
        best_prediction = sum(max(law[x,y,-1],law[x,y,1]) for x,y in itertools.product((-1,1),repeat=2))
        check(f'P1 parity formula t={t}', p_parity==(1+t)/2)
        check(f'P1 prediction formula t={t}',best_prediction==(1+abs(t))/2)
        h = entropy(law)
        check(f'P1 conditional entropy chain t={t}',abs((h-2)-entropy({0:(1+t)/2,1:(1-t)/2}))<1e-12)
        rows.append(dict(t=t,support=sum(p>0 for p in law.values()),mean=mu,covariance=cov,
                         entropy_bits=h,conditional_entropy_Z_given_XY_bits=h-2,
                         fixed_parity_probability=p_parity,best_prediction_success=best_prediction,
                         covariance_score_beta_1_nats=score(cov),law=law))
    for t,lt in laws.items():
        for s,ls in laws.items():
            check(f'P1 exact TV t={t},s={s}', tv(lt,ls)==abs(t-s)/2)
    return dict(rows=rows,tv_formula='TV(P_t,P_s)=abs(t-s)/2',
                score_formula='3*ln(1+beta), independent of t',
                conclusion='Covariance and all pair marginals miss the t-dependent joint continuation relation.')


def probe_two(out):
    laws = {
        'C':{(F(-2),F(0)):F(1,2),(F(2),F(0)):F(1,2)},
        'D':{(F(x),F(y)):F(1,4) for x,y in itertools.product((-1,1),repeat=2)},
        'E':{(F(x),F(y,2)):F(1,4) for x,y in itertools.product((-1,1),repeat=2)}
    }
    covs = {name:moments(law)[1] for name,law in laws.items()}
    expected = {'C':[[4,0],[0,0]],'D':[[1,0],[0,1]],'E':[[1,0],[0,F(1,4)]]}
    check('P2 exact covariances from explicit laws',covs==expected)
    betas_q = [F(1,100),F(1,10),F(1,2),F(1),F(2),F(3),F(10),F(100)]
    for beta,q in itertools.product(betas_q,repeat=2):
        det_c=1+4*beta
        det_d=(1+beta)*(1+q*beta)
        det_e=(1+beta)*(1+q*beta/4)
        check(f'P2 exact boundary b={beta},q={q}',det_d-det_c==beta*(q*(1+beta)-3))
        check(f'P2 E strictly dominated b={beta},q={q}',det_d>det_e)
        for name,det in [('C',det_c),('D',det_d),('E',det_e)]:
            numerical=score(covs[name],float(beta),np.diag([1.,float(q)]))
            check(f'P2 numeric determinant matches exact {name},b={beta},q={q}',abs(numerical-math.log(float(det)))<1e-11)

    # Coordinate transport: same law, new units, with and without metric transport.
    base={name:score(cov) for name,cov in covs.items()}
    s=np.diag([1.,10.])
    m_new=np.linalg.inv(s).T@np.linalg.inv(s)
    transformed={name:s@np.asarray(cov,dtype=float)@s.T for name,cov in covs.items()}
    naive={name:score(cov) for name,cov in transformed.items()}
    transported={name:score(cov,metric=m_new) for name,cov in transformed.items()}
    check('P2 naive units reverse C versus D',base['C']>base['D'] and naive['D']>naive['C'])
    check('P2 metric transport preserves scores',all(abs(base[n]-transported[n])<1e-12 for n in base))
    r=np.array([[.6,-.8],[.8,.6]])
    for name,cov in covs.items():
        check(f'P2 orthogonal feature invariance {name}',abs(score(r@np.asarray(cov,dtype=float)@r.T)-base[name])<1e-12)
        reversed_law=dict(reversed(list(laws[name].items())))
        check(f'P2 state enumeration invariance {name}',moments(reversed_law)[1]==cov)
        # A record-state bijection into integer-coded states with transported readouts.
        index_law={k:p for k,(_,p) in enumerate(laws[name].items())}
        readout={k:x for k,(x,_) in enumerate(laws[name].items())}
        recovered={readout[k]:p for k,p in index_law.items()}
        check(f'P2 implementation relabeling {name}',recovered==laws[name])

    beta_grid=np.geomspace(.01,100,161)
    q_grid=np.geomspace(.01,100,161)
    with (out/'probe2_phase_grid.csv').open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['beta','metric_q','winner','score_C_nats','score_D_nats','score_E_nats'])
        for beta in beta_grid:
            for q in q_grid:
                lc=math.log1p(4*beta)
                ld=math.log1p(beta)+math.log1p(q*beta)
                le=math.log1p(beta)+math.log1p(q*beta/4)
                winner='tie' if abs(ld-lc)<1e-12 else ('D' if ld>lc else 'C')
                writer.writerow([beta,q,winner,lc,ld,le])
    return dict(laws=laws,covariances=covs,
                regions={'C':'q*(1+beta)<3','D':'q*(1+beta)>3','C_D_tie':'q*(1+beta)=3','E':'never a maximizer for positive beta,q'},
                fixed_q_1_crossover_beta=2,
                coordinate_rescaling=dict(scale=[1,10],base_scores=base,naive_rescaled_scores=naive,transported_metric_scores=transported),
                numerical_grid=dict(beta=[.01,100,161],q=[.01,100,161],purpose='Visualization of analytically established boundary; not a prior over parameters.'))


def rare_metrics(p,m,beta=1.):
    p=F(p)
    law={0:1-p,**{i:p/m for i in range(1,m+1)}}
    check(f'P3 normalization m={m},p={p}',sum(law.values())==1 and all(v>=0 for v in law.values()))
    support=sum(v>0 for v in law.values())
    pf=float(p)
    cov_score=(m-1)*math.log1p(beta*pf/m)+math.log1p(beta*pf*(1-pf)/m)
    conditional=(m-1)*math.log1p(beta/m)
    trace=p-p*p/m
    h=entropy(law)
    check(f'P3 entropy chain m={m},p={p}',abs(h-(entropy({0:1-p,1:p})+pf*math.log2(m)))<1e-12)
    distance=tv(law,{0:F(1)})
    check(f'P3 operational distance m={m},p={p}',distance==p)
    check(f'P3 trace bound m={m},p={p}',cov_score<=beta*float(trace)+1e-12 and trace<=p)
    return dict(m=m,p_exact=p,p=pf,support=support,log2_support=math.log2(support),
                entropy_bits=h,covariance_score_nats=cov_score,covariance_trace_exact=trace,
                tv_to_narrow_exact=distance,conditional_broad_covariance_score_nats=conditional,
                conditional_broad_support=m,conditional_defined=bool(p))


def probe_three(out):
    probabilities=[F(0),F(1,10**12),F(1,10**9),F(1,10**6),F(1,1000),F(1,100),F(1,10),F(1,2),F(9,10),F(99,100),F(1)]
    rows=[rare_metrics(p,m) for m in (4,16,64) for p in probabilities]
    # Independent dense moment calculation validates the eigenvalue shortcut.
    for m in (4,16):
        for p in [F(1,10**6),F(1,100),F(1,2),F(1)]:
            zero=tuple(F(0) for _ in range(m))
            law={zero:1-p}
            for i in range(m):
                law[tuple(F(int(i==j)) for j in range(m))]=p/m
            _,cov=moments(law)
            expected=[[p/m*int(i==j)-p*p/(m*m) for j in range(m)] for i in range(m)]
            check(f'P3 exact dense covariance m={m},p={p}',cov==expected)
            analytic=(m-1)*math.log1p(float(p)/m)+math.log1p(float(p*(1-p))/m)
            check(f'P3 independent eigenvalue computation m={m},p={p}',abs(score(cov)-analytic)<1e-12)
    with (out/'probe3_probability_sweep.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(encode(row) for row in rows)
    return dict(rows=rows,beta=1,
                support_formula='m+1 for 0<p<1; 1 at p=0; m at p=1',
                entropy_formula='h2(p)+p*log2(m)',
                covariance_formula='(m-1)*ln(1+beta*p/m)+ln(1+beta*p*(1-p)/m)',
                bound='0 <= L_cov <= beta*(p-p^2/m) <= beta*p',
                probability_distance_formula='TV(P_p,P_0)=p',
                limitation='The uniform-in-m covariance bound assumes the declared unit-norm one-hot features and fixed beta.')


def plot_results(out,p1):
    plt.rcParams.update({'font.size':10,'axes.titlesize':12,'axes.labelsize':10,'figure.facecolor':'white'})
    fig,axes=plt.subplots(2,2,figsize=(12.5,9.2),layout='constrained')
    ax=axes[0,0]
    ts=np.linspace(-1,1,401)
    cond=[]
    for t in ts:
        v=(1+t)/2
        cond.append(-sum(a*math.log2(a) for a in [v,1-v] if a>0))
    ax.plot(ts,np.ones_like(ts),label='Covariance score / (3 ln 2)',color='#64748b',linewidth=2)
    ax.plot(ts,cond,label='H(Z | X,Y), bits',color='#008c95',linewidth=2)
    ax.plot(ts,(1+np.abs(ts))/2,label='Best prediction probability',color='#be5e00',linewidth=2)
    ax.set(xlabel='Dependence parameter t',ylabel='Diagnostic (different units; see legend)',title='1. Covariance misses joint dependence',ylim=(-.04,1.12))
    ax.legend(loc='lower center',fontsize=8)
    ax.grid(alpha=.2)

    ax=axes[0,1]
    betas=np.geomspace(.01,100,501)
    qs=np.geomspace(.01,100,501)
    b,q=np.meshgrid(betas,qs)
    ax.pcolormesh(b,q,(q*(1+b)>3).astype(int),cmap=ListedColormap(['#dce6f4','#bde6dc']),shading='auto',rasterized=True)
    ax.plot(betas,3/(1+betas),color='#213547',linewidth=2,label='Tie: q = 3 / (1 + beta)')
    ax.scatter([2],[1],color='#172b4d',s=28,zorder=3)
    ax.text(.025,.03,'C preferred',fontsize=11)
    ax.text(.04,15,'D preferred',fontsize=11)
    ax.text(.035,.09,'E never wins',fontsize=9)
    ax.set(xscale='log',yscale='log',xlabel='Covariance scale beta',ylabel='Metric weight q',title='2. Exact ranking regions')
    ax.legend(loc='lower right',fontsize=8)

    ax=axes[1,0]
    ps=np.geomspace(1e-12,1e-1,400)
    m=16
    hs=np.array([-(1-p)*math.log2(1-p)-p*math.log2(p)+p*math.log2(m) for p in ps])
    ls=(m-1)*np.log1p(ps/m)+np.log1p(ps*(1-ps)/m)
    ax.plot(ps,np.full_like(ps,math.log2(m+1)),label='Log support (bits)',color='#64748b',linewidth=2)
    ax.plot(ps,hs,label='Shannon entropy (bits)',color='#008c95',linewidth=2)
    ax.plot(ps,ls,label='Covariance score (nats)',color='#be5e00',linewidth=2)
    ax.set(xscale='log',yscale='log',xlabel='Broad-continuation probability p',ylabel='Separate diagnostics (different units)',title='3. Fixed support, vanishing probability: m = 16')
    ax.legend(loc='upper left',fontsize=8)
    ax.grid(alpha=.2)

    ax=axes[1,1]
    ax.plot(ps,np.ones_like(ps),color='#64748b',linestyle='--',linewidth=2,label='Proved bound: L / p <= 1')
    colors=['#be5e00','#008c95','#6f52a5']
    for m,color in zip((4,16,64),colors):
        ls=(m-1)*np.log1p(ps/m)+np.log1p(ps*(1-ps)/m)
        ax.plot(ps,ls/ps,color=color,linewidth=2,label=f'm = {m}')
    # Ratio plot makes dimension dependence visible instead of overplotting scores.
    ax.set(xscale='log',xlabel='Broad-continuation probability p',ylabel='Covariance score / p (beta = 1)',title='3. Tail bound with fixed unit-norm features',ylim=(.95,1.004))
    ax.legend(loc='lower left',fontsize=8)
    ax.grid(alpha=.2)
    fig.suptitle('Finite structural probes — no ethical reward function',fontsize=16)
    fig.savefig(out/'probe_overview.png',dpi=175)
    fig.savefig(out/'probe_overview.svg')
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('results'))
    args=parser.parse_args()
    out=args.out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    p1=probe_one()
    p2=probe_two(out)
    p3=probe_three(out)
    calculation_seconds=time.perf_counter()-started
    results=dict(scope='Exact finite classical record processes; diagonal quantum special case.',
                 probe1=p1,probe2=p2,probe3=p3,
                 verification=dict(check_count=len(CHECKS),checks=CHECKS,all_passed=True),
                 reproducibility=dict(python=platform.python_version(),numpy=np.__version__,matplotlib=matplotlib.__version__,
                     source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                     calculation_seconds=calculation_seconds,random_sampling=False))
    (out/'results.json').write_text(json.dumps(encode(results),indent=2)+'\n')
    plot_results(out,p1)
    print(json.dumps(dict(status='passed',checks=len(CHECKS),calculation_seconds=round(calculation_seconds,3),
                         total_seconds=round(time.perf_counter()-started,3),out=str(out)),indent=2))


if __name__=='__main__':
    main()
