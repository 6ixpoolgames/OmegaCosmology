# Lushness: finite structural probes 1–3

Start with `REPORT.md`. `MODEL_SPEC.md` gives the full assumptions. The work deliberately stops below agent/ethical-environment modeling.

## Reproduce

```bash
python -m pip install -r requirements.txt
python run_probes.py --out results
```

Python 3.10 or newer is sufficient. The recorded run used the installed NumPy and Matplotlib versions listed in `results/results.json`. No network is used by the script itself. No sampling seeds are needed because the calculations are deterministic.

## Contents

- `run_probes.py`: exact finite law and moment calculations, analytic boundary verification, probability sweeps, and figures.
- `REPORT.md` / `REPORT.txt`: findings, derivations, and implications.
- `MODEL_SPEC.md`: preparation laws, readout conventions, and scope.
- `results/results.json`: exact fractions, scores, verification ledger, and run provenance.
- `results/probe2_phase_grid.csv`: numerical view of an analytically proved boundary.
- `results/probe3_probability_sweep.csv`: fixed-support probability sweep.
- `results/probe_overview.png` / `.svg`: scientific figure, with separate diagnostic units identified.
- `MANIFEST.json`: SHA-256 hashes of deliverables, excluding the manifest itself.

Rerunning replaces files in the specified output directory. Runtime metadata will differ between runs. Regenerate the manifest if distributing modified outputs. The scalar candidates remain distinct from the full continuation object; equal or different scores alone are not established ethical verdicts.
