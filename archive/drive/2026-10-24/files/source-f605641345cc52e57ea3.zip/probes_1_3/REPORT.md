# Lushness probes 1–3: results and implications

23 September 2026

## Outcome

All three probes were completed using exact finite probability laws. They establish three useful facts about the current candidates:

1. The original-record covariance misses a continuously variable joint dependency that changes subsequent prediction.
2. The covariance candidate has exactly characterizable winning regions. Its calibration can reverse a ranking, but not every alternative can be made a winner within the declared family.
3. Support alone cannot distinguish a rare broad continuation from a common one. Under fixed unit-norm features, the covariance candidate has a provable probability-tail bound independent of the number of broad records.

These are structural results. No agent model, supplied ethical reward, protective rule, or higher-level policy environment was used. They constrain the machinery available for a future adjudicator without identifying value itself.

The calculations took approximately 0.20 seconds. Calculation and figure generation together took approximately 1.89 seconds after imports; the environment's full command took approximately 3.6 seconds. Exact probability and moment calculations were checked against analytic formulas and independent numerical matrix calculations. All 559 recorded consistency checks passed. This count describes implementation verification, not the number of independent scientific results.

## 1. A joint dependency invisible to covariance

Let X,Y,Z be binary records taking values -1 or +1. The full preparation law is

    P_t(x,y,z) = (1 + t xyz)/8, with -1 <= t <= 1.

At t=0 the records are independent. At t=1, Z=XY. At t=-1, Z=-XY. Intermediate t continuously changes the reliability of this relation. Every law has the same three means, the same uniform two-record marginals, and covariance I_3.

Consequently, the current covariance candidate is constant throughout the family:

    L_cov(beta) = 3 ln(1+beta).

But its sequential response is not constant. Once X and Y are known,

    P(Z=XY | X,Y) = (1+t)/2.
    Best prediction success = (1+|t|)/2.
    H(Z | X,Y) = h2((1+t)/2).

Here h2 is binary Shannon entropy. Exact enumeration gives:

| t | Positive-weight records | Best prediction of Z after X,Y | H(Z given X,Y), bits | Covariance score, beta=1 |
| --- | ---: | ---: | ---: | ---: |
| -1 | 4 | 1 | 0 | 2.079442 |
| -1/2 | 8 | 3/4 | 0.811278 | 2.079442 |
| 0 | 8 | 1/2 | 1 | 2.079442 |
| 1/2 | 8 | 3/4 | 0.811278 | 2.079442 |
| 1 | 4 | 1 | 0 | 2.079442 |

The full operational readout distinguishes the preparations. Its total variation distance is exactly

    TV(P_t,P_s) = |t-s|/2.

This follows because each of the eight probability differences has magnitude |t-s|/8. In particular, the two endpoint laws are perfectly distinguishable, although their covariance and entropy agree.

**What this establishes.** Covariance of these original coordinates is not sufficient to reconstruct the joint response structure. No adjustment of beta, or fixed linear change of these coordinates, repairs that loss. A richer feature map could expose the dependency, but choosing and calibrating that map would become part of the construction.

**What it does not establish.** A richness score need not distinguish every operationally different process. The opposite-parity endpoints may appropriately have equal richness under a symmetry-respecting comparison. This probe therefore rejects covariance as a sufficient representation of the relevant relations; it does not prove that every equal covariance score is a wrong value judgment. The important question is whether omitted relations can become consequential under the subsequent composition we wish to assess.

No preference for predictable order over independent randomness was supplied. Both are retained in the full object.

## 2. Exact tuning regions and a coordinate trap

Three explicitly enumerated record preparations have covariances

    C: diag(4,0)
    D: diag(1,1)
    E: diag(1,1/4).

They arise from equal probabilities on, respectively, (+/-2,0), (+/-1,+/-1), and (+/-1,+/-1/2). Their supports share a common finite alphabet and fixed numerical readout convention. Unequal feature spreads are intentional; no resource-efficiency claim is made.

Give the two features a metric M=diag(1,q), q>0, and consider

    L(beta,M,Sigma) = ln det(I + beta Sigma M), beta>0.

The three scores are logarithms of

    C: 1+4 beta
    D: (1+beta)(1+q beta)
    E: (1+beta)(1+q beta/4).

Because logarithm is increasing, subtracting the first two determinant expressions gives the exact decision boundary:

    det_D - det_C = beta [q(1+beta)-3].

| Parameter region | Winner |
| --- | --- |
| q(1+beta)<3 | C |
| q(1+beta)=3 | C and D tie |
| q(1+beta)>3 | D |
| Any positive beta and q | E is strictly below D and never wins |

At q=1 the crossover occurs at beta=2. At beta=1 it occurs at q=3/2. The figure and 25,921-row CSV visualize this analytic boundary. Grid coverage is not the basis of the proof and is not a probability distribution over evaluative choices.

**Answer to the tuning question.** This family permits a choice between C and D through calibration, but no allowed tuning makes E a winner. That exclusion applies to the declared score family, not every conceivable account of value. Widening the feature or functional family can change the available conclusions.

### The same world, different units

At beta=q=1, C scores 1.609438 and D scores 1.386294. C wins. Merely multiplying the numerical units of the second readout by ten, while leaving the metric numerically fixed, makes D score 5.308268 and appear to win.

Transporting the metric along with the coordinate change restores the original scores exactly within numerical tolerance:

    Sigma' = S Sigma S^T
    M' = S^(-T) M S^(-1).

Indeed, Sigma'M' = S(Sigma M)S^(-1), so the determinants agree. Orthogonal feature changes and record-state relabeling also preserve the correctly transported comparison.

This exposes a specific calibration debt: a coordinate choice must not silently become an ethical weight. A physically justified feature metric could resolve that freedom. The experiment does not provide one.

## 3. Rare breadth, support, and a probability bound

The model has a narrow record 0 and m distinguishable broad records. A physical flag enters the broad continuation with probability p, then selects its record uniformly:

    P(0)=1-p; P(i)=p/m, i=1,...,m.

At fixed m, every 0<p<1 has precisely the same support. With full readout, distinct records have operational distance one, so the small-resolution covering number is m+1. Changing p from one in a trillion to one half leaves that covering number unchanged.

The full probability object nevertheless approaches the narrow preparation as p approaches zero:

    TV(P_p,P_0)=p.

Shannon entropy tracks the changing weights:

    H(P_p)=h2(p)+p log2(m).

For the covariance calculation, use the declared features phi(0)=0 and phi(i)=e_i. Every feature has norm at most one. Then

    Sigma = (p/m)I - (p^2/m^2)11^T,
    L_cov = (m-1)ln(1+beta p/m) + ln(1+beta p(1-p)/m).

For m=16 and beta=1:

| Probability p | Support | Entropy, bits | Covariance score, nats |
| --- | ---: | ---: | ---: |
| 0 | 1 | 0 | 0 |
| 10^-12 | 17 | 4.53058e-11 | approximately 1e-12 |
| 10^-6 | 17 | 2.53743e-5 | 9.999999e-7 |
| 0.01 | 17 | 0.120793 | 0.00999063 |
| 0.5 | 17 | 3 | 0.477079 |
| 0.9 | 17 | 4.068996 | 0.826483 |
| 1 | 16 | 4 | 0.909369 |

The decrease from 17 to 16 records at p=1 is real: the narrow record then has zero probability. The entropy can peak before p=1 because it also represents uncertainty between narrow and broad outcomes. Neither fact is an ethical verdict.

### What conditioning discards

Conditional on reaching the broad continuation, the covariance score is always

    (m-1)ln(1+beta/m).

For m=16 and beta=1, this is 0.909369 whether p is one in a million or one half. The conditional record law contains no information about the probability of reaching it. A comparison that keeps only this normalized law loses a consequential difference before any ethical weighting occurs. At p=0 the conditional preparation is undefined; its component formula can be displayed only as a reference law, not as an observed conditional event.

### A proved bound, with its cost visible

For every nonnegative eigenvalue lambda, ln(1+beta lambda)<=beta lambda. Therefore

    0 <= L_cov <= beta Tr(Sigma)
              = beta(p-p^2/m)
              <= beta p.

This holds for every positive integer m, every 0<=p<=1, and fixed beta>0. Increasing the number of orthogonal broad records cannot defeat the rare-event suppression within this calibration. Explicit sweeps used m=4,16,64; the inequality establishes the general result.

The same result exposes a limitation: at fixed p and beta, letting m increase without bound gives L_cov -> beta p. The score saturates even as the number of distinguishable records increases. That might be appropriate for bounded geometry, or it might compress precisely the breadth lushness was meant to register. The experiment does not settle that interpretation.

This is not a universal solution to small-probability/high-stakes decisions. The bound depends on the fixed feature norm and beta. If represented magnitudes or the calibration grow with the proposed consequence, the uniform bound does not transfer unchanged. No premise establishing that all value has this bounded geometry has been supplied.

## What the three probes change

| Component | Status after the probes |
| --- | --- |
| Full joint, weighted continuation object | Retains all the tested distinctions; remains the reference object |
| Original-coordinate covariance | A usable summary, insufficient to reconstruct higher-order dependence |
| Unweighted support or small-resolution covering number | Describes possibility, but does not adjudicate likelihood at fixed support |
| Covariance calibration | Has provable decision regions; needs an independently justified metric and scale |
| Rare-event control | Demonstrated conditionally for the bounded feature construction; accompanied by saturation of breadth |
| Ethical adjudication | Not established by these structural calculations |

The clearest next question remains below the agency layer: can a comparison built from full conditional response structure retain the dependence lost in Probe 1 while controlling the probability behavior diagnosed in Probe 3, without obtaining its ordering from arbitrary feature units? A small compositional process comparison can address that before any engineered ethical environment is introduced.

## Reproduction and provenance

Run `python run_probes.py --out results` after installing the two dependencies listed in `requirements.txt`. The script emits exact rational probabilities and covariances, numerical score values, both CSV files, a verification ledger, and PNG/SVG figures. It uses no random sampling or external services.

`MODEL_SPEC.md` states the model domains and interpretation rules. `results/results.json` records the source hash, runtime versions, and every consistency check. `MANIFEST.json` records hashes of the packaged files.

The work applies Parts 04–05 and 14 of the current Omega primer. Higher-order dependence, covariance calibration, and the logarithm bound are established mathematical phenomena used here as diagnostics. Their application identifies concrete limits and choices in the present research candidates; it is not a claim of a new physics theorem. No web research was needed to calculate these finite examples.
