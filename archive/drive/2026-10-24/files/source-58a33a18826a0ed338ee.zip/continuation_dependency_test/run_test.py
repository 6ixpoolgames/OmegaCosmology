#!/usr/bin/env python3
"""Finite reversible continuation diagnostic. No sampling or network.
Run: python run_test.py --out results
Only plotting requires matplotlib; all probability arithmetic is Fraction.
"""
from __future__ import annotations
import argparse
from collections import Counter
import csv
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

STATES=list(itertools.product((-1,1),repeat=3))
PAIRS=list(itertools.product((-1,1),repeat=2))
CHECKS=Counter()


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    CHECKS[name]+=1


def law(t):
    return {s:(1+t*s[0]*s[1]*s[2])/8 for s in STATES}


def moments(p):
    n=len(next(iter(p)))
    mean=[sum(v*s[i] for s,v in p.items()) for i in range(n)]
    cov=[[sum(v*(s[i]-mean[i])*(s[j]-mean[j]) for s,v in p.items()) for j in range(n)] for i in range(n)]
    return mean,cov


def entropy(p):
    return -sum(float(v)*math.log2(float(v)) for v in p.values() if v)


def tv(p,q):
    return sum(abs(p.get(s,F(0))-q.get(s,F(0))) for s in p.keys()|q.keys())/2


def push(p, mapping):
    result={}
    for s,v in p.items():
        y=mapping[s]
        result[y]=result.get(y,F(0))+v
    return result


def one_bit(p):
    return {w:sum(v for s,v in p.items() if s[-1]==w) for w in (-1,1)}


def physical_joint(p,decoder):
    result={}
    for u in (-1,1):
        for (x,y,z),v in p.items():
            out=decoder[(x,y,u*z)]
            key=(u,)+out
            result[key]=result.get(key,F(0))+v/2
    return result


def conditioned_outputs(p,decoder):
    return {u:one_bit(push(p,{(x,y,z):decoder[(x,y,u*z)] for x,y,z in STATES})) for u in (-1,1)}


def recover_input(channel):
    return sum(max(channel[-1][w],channel[1][w])/2 for w in (-1,1))


def mi_fair(channel):
    marginal={w:(channel[-1][w]+channel[1][w])/2 for w in (-1,1)}
    return entropy(marginal)-(entropy(channel[-1])+entropy(channel[1]))/2


def all_decoders():
    result=[]
    for j,positive in enumerate(itertools.combinations(STATES,4)):
        positives=set(positive)
        f={s:(1 if s in positives else -1) for s in STATES}
        decoder={}
        for w in (-1,1):
            group=[s for s in STATES if f[s]==w]
            for s,xy in zip(group,PAIRS):
                decoder[s]=xy+(w,)
        check('every balanced readout has a reversible extension',len(set(decoder.values()))==8)
        c=sum(F(s[0]*s[1]*s[2]*f[s],8) for s in STATES)
        result.append(dict(id=j,f=f,decoder=decoder,c=c))
    check('decoder class has 70 functions',len(result)==70)
    return result


def cover_two(distance,epsilon,delta):
    """Exhaustively cover a two-atom uniform family, centers in that family."""
    d=[[F(0),distance],[distance,F(0)]]
    for n in (1,2):
        for centers in itertools.combinations((0,1),n):
            mass=sum(F(1,2) for j in (0,1) if any(d[i][j]<=epsilon for i in centers))
            if mass>=1-delta:
                return n
    raise AssertionError('full family must cover itself')


def encode(v):
    if isinstance(v,F): return str(v)
    if isinstance(v,dict):
        if v and all(isinstance(k,tuple) for k in v):
            return [{'state':encode(k),'value':encode(x)} for k,x in v.items()]
        return {str(k):encode(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)): return [encode(x) for x in v]
    return v


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('results'))
    out=parser.parse_args().out.resolve()
    out.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    decoders=all_decoders()
    class_counts=Counter(d['c'] for d in decoders)
    check('exact decoder coefficient multiplicities',class_counts=={F(-1):1,F(-1,2):16,F(0):36,F(1,2):16,F(1):1})
    ts=[F(i,8) for i in range(-8,9)]
    parity={(x,y,z):(x,y,x*y*z) for x,y,z in STATES}
    identity={s:s for s in STATES}
    check('parity circuit is reversible and self inverse',all(parity[parity[s]]==s for s in STATES))
    feature_subsets=[inds for n in range(4) for inds in itertools.combinations(range(3),n)]
    features={inds:tuple(math.prod(s[i] for i in inds) for s in STATES) for inds in feature_subsets}
    for a,b in itertools.product(feature_subsets,repeat=2):
        check('full product basis is orthogonal and complete',sum(x*y for x,y in zip(features[a],features[b]))==(8 if a==b else 0))
    check('future readout pulls back to missing triple product',tuple(parity[s][2] for s in STATES)==features[(0,1,2)])
    rows=[]
    examples=[]
    geometry=[]
    decoder_sweep=[]
    identity_cov=[[int(i==j) for j in range(3)] for i in range(3)]

    for t in ts:
        p=law(t)
        check('input laws normalized and nonnegative',sum(p.values())==1 and all(v>=0 for v in p.values()))
        mu,cov=moments(p)
        check('same input means and covariance',mu==[0,0,0] and cov==identity_cov)
        raw_moments={inds:sum(p[s]*features[inds][j] for j,s in enumerate(STATES)) for inds in feature_subsets}
        reconstructed={s:sum(raw_moments[inds]*features[inds][j] for inds in feature_subsets)/8 for j,s in enumerate(STATES)}
        check('completed observable basis reconstructs the full law',reconstructed==p)
        check('third product moment carries the missed parameter',raw_moments[(0,1,2)]==t)
        after=push(p,parity)
        mu_after,cov_after=moments(after)
        check('fixed reversible decoder exposes third moment',mu_after==[0,0,t] and cov_after==[[1,0,0],[0,1,0],[0,0,1-t*t]])
        check('reversible circuit preserves complete law',push(after,parity)==p)
        check('reversible circuit preserves entropy',abs(entropy(after)-entropy(p))<1e-12)
        channels=conditioned_outputs(p,parity)
        channels_control=conditioned_outputs(p,identity)
        full_joint=physical_joint(p,parity)
        receiver_joint={(u,w):sum(v for (uu,x,y,ww),v in full_joint.items() if uu==u and ww==w) for u,w in itertools.product((-1,1),repeat=2)}
        check('full joint is normalized',sum(full_joint.values())==1)
        register_marginal={s:sum(v for (u,x,y,w),v in full_joint.items() if (x,y,w)==s) for s in STATES}
        check('full receiver register marginal is uniform after averaging input',all(v==F(1,8) for v in register_marginal.values()))
        check('full object retains input-output correlation',sum(F(u*w)*v for (u,x,y,w),v in full_joint.items())==t)
        check('parity receiver channel law',all(channels[u][w]==(1+t*u*w)/2 for u,w in itertools.product((-1,1),repeat=2)))
        check('joint conditioning agrees with direct channel calculation',all(receiver_joint[u,w]==channels[u][w]/2 for u,w in itertools.product((-1,1),repeat=2)))
        check('negative control cannot transmit through W',all(channels_control[u][w]==F(1,2) for u,w in itertools.product((-1,1),repeat=2)))
        d=tv(channels[-1],channels[1])
        check('optimal parity separation is abs(t)',d==abs(t))
        check('input recovery formula',recover_input(channels)==(1+abs(t))/2)
        marginal_w={w:(channels[-1][w]+channels[1][w])/2 for w in (-1,1)}
        check('unconditional receiver looks identical for all t',marginal_w=={-1:F(1,2),1:F(1,2)})
        # Similarity-sensitive diversity for the actual fair input ensemble.
        similarity=1-d
        d2=1/(F(1,4)+F(1,2)*similarity+F(1,4))
        check('candidate D2 formula',d2==1/(1-abs(t)/2))
        row=dict(t=t,original_support=sum(v>0 for v in p.values()),original_entropy_bits=entropy(p),
                 original_covariance_score_beta1_nats=3*math.log(2),receiver_separation=d,
                 best_input_recovery=recover_input(channels),input_output_mutual_information_bits=mi_fair(channels),
                 control_separation=tv(channels_control[-1],channels_control[1]),candidate_D2=d2)
        rows.append(row)
        if t in (F(-1),F(0),F(1,2),F(1)):
            examples.append(dict(t=t,input_law=p,full_joint_after=full_joint,parity_receiver_channel=channels,
                                 control_receiver_channel=channels_control,after_fixed_gate_mean=mu_after,after_fixed_gate_covariance=cov_after))

        separations=[]
        for record in decoders:
            c=record['c']
            channel=conditioned_outputs(p,record['decoder'])
            check('exhaustive decoder response formula',all(channel[u][w]==(1+t*c*u*w)/2 for u,w in itertools.product((-1,1),repeat=2)))
            distance=tv(channel[-1],channel[1])
            check('exhaustive decoder bound',distance==abs(t*c) and distance<=abs(t))
            separations.append(distance)
            decoder_sweep.append(dict(t=t,decoder_id=record['id'],parity_coefficient=c,
                                      separation=distance,best_input_recovery=recover_input(channel)))
        check('maximum over all balanced reversible readouts',max(separations)==abs(t))
        if t:
            check('readout multiplicities at nonzero t',Counter(separations)=={F(0):36,abs(t)/2:32,abs(t):2})

        for epsilon in (F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(1)):
            for delta in (F(0),F(1,4),F(1,2)):
                n=cover_two(d,epsilon,delta)
                expected=1 if epsilon>=d or delta>=F(1,2) else 2
                check('weighted cover formula including exact boundaries',n==expected)
                geometry.append(dict(t=t,epsilon=epsilon,delta=delta,cover_number=n))

    # Receiver-only stochastic postprocessing: no access to input U.
    simulation_rows=[]
    for t,s in itertools.product(ts,repeat=2):
        if abs(s)<=abs(t):
            r=F(0) if t==0 else s/t
            coin={1:(1+r)/2,-1:(1-r)/2}
            source=conditioned_outputs(law(t),parity)
            target=conditioned_outputs(law(s),parity)
            simulated={u:{v:sum(source[u][w]*coin[v*w] for w in (-1,1)) for v in (-1,1)} for u in (-1,1)}
            check('receiver-only randomization simulates weaker response',simulated==target)
            simulation_rows.append(dict(source_t=t,target_t=s,flip_probability=coin[-1]))

    # Global reversibility is independent of the chosen receiver projection.
    for t,s in itertools.product(ts,repeat=2):
        check('global law distance preserved under parity permutation',tv(push(law(t),parity),push(law(s),parity))==tv(law(t),law(s)))

    for filename,data in [('summary.csv',rows),('decoder_sweep.csv',decoder_sweep),('cover_profiles.csv',geometry)]:
        with (out/filename).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(encode(row) for row in data)
    calculation_time=time.perf_counter()-start
    result=dict(experiment='Covariance-hidden dependence under reversible continuation',
                parameters=dict(t_grid=ts,bits=3,balanced_readouts=70,random_sampling=False),
                observable_completion=dict(initial_span_dimension=7,completed_span_dimension=8,
                    required_added_observable='XYZ',reason='Pullback of the actual future W readout through the reversible parity circuit'),
                decoder_coefficient_counts=class_counts,summary=rows,examples=examples,
                decoders=[dict(id=d['id'],coefficient=d['c'],positive_states=[s for s in STATES if d['f'][s]==1],reversible_map=d['decoder']) for d in decoders],
                receiver_simulations=simulation_rows,
                checks=dict(all_passed=True,by_category=dict(CHECKS),total=sum(CHECKS.values())),
                reproducibility=dict(python=platform.python_version(),matplotlib=matplotlib.__version__,
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calculation_seconds=calculation_time),
                formulas=dict(channel='P(W=w|U=u,t,f)=(1+t*c_f*u*w)/2',
                    max_separation='abs(t)',best_recovery='(1+abs(t))/2',
                    candidate_D2='1/(1-abs(t)/2)',
                    candidate_cover='1 if epsilon>=abs(t) or delta>=1/2, otherwise 2'))
    (out/'results.json').write_text(json.dumps(encode(result),indent=2)+'\n')

    fig,axes=plt.subplots(1,3,figsize=(14,4.7),layout='constrained')
    positive=[r for r in rows if r['t']>=0]
    x=[float(r['t']) for r in positive]
    ax=axes[0]
    ax.plot(x,[1]*len(x),color='#64748b',linestyle='--',label='Input covariance score / (3 ln 2)')
    ax.plot(x,[float(r['receiver_separation']) for r in positive],color='#008c95',marker='o',label='Maximum receiver separation')
    ax.plot(x,[0]*len(x),color='#bc6200',linestyle=':',linewidth=2,label='Undecoded-port control')
    ax.set(title='Same covariance, different response',xlabel='Dependency strength |t|',ylabel='Separate diagnostics',ylim=(-.04,1.07))
    ax.legend(fontsize=8,loc='upper left')
    ax.grid(alpha=.2)
    ax=axes[1]
    ax.bar(['No transfer','Partial','Maximal'],[36,32,2],color=['#94a3b8','#76c5bd','#007f83'])
    for i,y in enumerate((36,32,2)): ax.text(i,y+.6,str(y),ha='center')
    ax.set(title='All 70 balanced readouts',ylabel='Number of readouts',ylim=(0,42))
    ax.text(.5,-.21,'For nonzero t; counts are not a prior over operations',transform=ax.transAxes,ha='center',fontsize=8)
    ax=axes[2]
    ax.plot(x,[float(r['candidate_D2']) for r in positive],color='#6552a3',marker='o')
    ax.set(title='Candidate response diversity',xlabel='Dependency strength |t|',ylabel='D2 for fair input; similarity = 1 - TV',ylim=(.96,2.07))
    ax.grid(alpha=.2)
    fig.suptitle('A covariance-hidden relation changes usable continuation responses',fontsize=14)
    fig.savefig(out/'continuation_dependency.png',dpi=170)
    fig.savefig(out/'continuation_dependency.svg')
    plt.close(fig)
    print(json.dumps(dict(status='passed',checks=sum(CHECKS.values()),categories=len(CHECKS),
                         readouts=70,parameter_values=len(ts),calculation_seconds=round(calculation_time,3),
                         total_seconds=round(time.perf_counter()-start,3)),indent=2))


if __name__=='__main__': main()
