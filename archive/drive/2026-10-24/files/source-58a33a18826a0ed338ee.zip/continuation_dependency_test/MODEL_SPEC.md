# Continuation dependency test: exact specification

## Question

Does the higher-order dependency missed by the covariance probe change an available physical continuation response, or is it merely a difference with no consequence in the tested continuation?

This is a test of a three-bit reversible device. It contains no valuer labels, reward function, rights, or policy ecology. It tests a structural ingredient that lushness is intended to assess. It does not stipulate that one device has greater overall value.

## Initial preparations

Reuse the complete joint laws from Probe 1:

    P_t(x,y,z) = (1 + t xyz)/8, x,y,z in {-1,+1}, -1 <= t <= 1.

All have zero means and covariance I_3. At t=0 all records are independent. At t=1 the relation Z=XY is exact. The full joint law is retained throughout.

## Input and reversible continuation

An independent binary input U selects a reversible sign flip of Z:

    (x,y,z) -> (x,y,u z).

A fixed decoder subsequently permutes the eight register states and exposes its last output bit W. U remains recorded; all three output bits are retained in the full model. The transformation is a bijection conditional on U and has a permutation-unitary realization on diagonal three-qubit states.

No direct wire from U to W, fresh blank receiver register, or reset operation is permitted in this interface. The same allowed operations apply to every t. Preparation entropies differ; no claim of equal preparation cost or comparative energy efficiency is made.

The simple decoder (x,y,z') -> (x,y,xyz') yields W=UXYZ. A negative control uses W=UZ, exposing the encoded last bit without parity decoding. The latter control does not make the hidden dependency disappear globally; it tests a receiver readout that cannot access it.

## Exhaustive one-bit decoder class

Any output bit of an eight-state permutation is a balanced Boolean function f: four states map to +1 and four to -1. Conversely, every such function extends to a reversible permutation by assigning the other two output bits bijectively within each four-state preimage.

There are choose(8,4)=70 such functions. Enumerate all of them and construct an explicit reversible extension for each. This exhausts the distinct one-bit readouts of reversible decoders on these registers. It does not enumerate every possible physical experiment, extra ancilla, reset channel, or quantum coherent operation.

Define c_f = (1/8) sum_{x,y,z} xyz f(x,y,z). Then direct calculation predicts

    P(W=w | U=u,t,f) = [1 + t c_f u w]/2.

The enumeration tests this formula against the full transformed laws. No probability prior is placed over decoder choices.

## Quantities assessed

1. Covariance before and after the fixed parity decoder with U=+1. This tests whether the covariance summary supports a well-defined exact continuation update.
2. The two conditional receiver laws for U=+1 and U=-1, and their total variation distance.
3. Best recovery of the input from W under an actual independent fair input source. No ethical utility is assigned to this diagnostic.
4. The entropy and full-law distinguishability preserved by the reversible transformation, as checks against invented erasure or information creation.
5. Two candidate response-geometry probes: exact weighted covering numbers and D2 diversity with declared similarity Z_ij=1-TV(P_i,P_j). These are applied to the two conditional receiver laws, with weights 1/2 from the physical input source.

For the covering profile, centers must be members of the two-law family; balls are closed. Let epsilon >= 0 be the radius and 0 <= delta < 1 the allowed uncovered mass. The profile is retained rather than choosing a single ethical tolerance.

The linear similarity 1-TV is a declared candidate, not a uniqueness result. These response-geometry probes measure a specific conditional response repertoire, not the global value of the complete model.

The analysis also checks the observable completion required by this continuation. Constants, first moments, and pair products span seven of the eight classical record observables. Pulling the actual future W readout back through the parity circuit requires XYZ, the missing eighth observable. The full product basis must reconstruct each tested joint law exactly. This is an application of the existing continuation-closure rule, not an independently rewarded correlation feature.

## A conditional simulation check

As a separate diagnostic, allow the receiver to apply an input-independent stochastic transformation to W, with its randomizer explicitly permitted for both compared channels. For parity channels with |s| <= |t| and t nonzero, multiplying W by an independent sign R with E[R]=s/t simulates the weaker channel s.

Check this law exactly. A receiver operation cannot increase the total variation between the two input-conditioned outputs, so the converse is unavailable when |s|>|t|. This is a comparison of a specified information-transfer capability, not an ethical ordering or a claim that all global structure is ordered by t.

## Scope and interpretation

The receiver cannot directly inspect U or the other two register outputs. The complete object retains those records. An unrestricted global readout of U trivially distinguishes the input values for every t; that is not the property being measured. The question is transfer into the specified W interface, a physical relation inside the full object.

The construction has been chosen to test whether an available dependency can become usable under lawful composition. The exhaustive decoder class provides positive, partial, and negative controls. A successful result establishes that the covariance omission can matter to conditional continuation capability. It does not identify capability with value, require all scalar lushness measures to distinguish the preparations, or establish generativity in the full cosmological sense.

This applies the existing primer's composition and tester-equivalence criteria. The underlying reversible probability identities are elementary; the result is a concrete witness within the program, not a new physical theorem.
