# Continuation dependency test

Read `REPORT.md`, then `MODEL_SPEC.md` for the physical interface and assumptions.

```bash
python -m pip install -r requirements.txt
python run_test.py --out results
```

Python 3.10 or newer. Matplotlib is the only external dependency. Probability arithmetic uses the standard library's Fraction type; no randomness or network is used by the experiment.

The test asks whether the correlation missed by the original covariance probe affects an actual reversible continuation capability. It does not instantiate a high-level ethical environment.

Results retain all 70 decoder maps, exact example full joint laws, the readout sweep, response-geometry profiles, provenance, and figures. They distinguish the complete model from its physically specified receiver interface.

Rerunning replaces files in the selected output directory. Runtime provenance may differ between runs. Regenerate `MANIFEST.json` if redistributing changed files.
