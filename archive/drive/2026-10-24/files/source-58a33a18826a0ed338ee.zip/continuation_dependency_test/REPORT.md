# Does the omitted dependency change continuation capability?

23 September 2026

## Result

Yes, within an explicit physical interface. The higher-order dependency missed by the original covariance probe can enable a reversible three-bit device to transmit a binary input perfectly. The independent preparation cannot transmit that input through the same interface. Initial covariance scores remain identical.

The complete continuation representation predicts this difference correctly. We have found a consequential limitation of the covariance summary, not a failure of that representation or a proof of an overall value ranking.

The test stays below agent modeling: finite probability laws, reversible register transformations, specified inputs and readouts. Exact enumeration covers all 70 distinct balanced one-bit readouts of three-bit reversible decoders.

## 1. The device

Reuse the initial laws

    P_t(x,y,z) = (1+t xyz)/8, for x,y,z in {-1,+1}.

At t=0, X,Y,Z are independent fair bits. At t=1, Z=XY. Intermediate t changes the reliability of that relation. All these preparations have zero means and covariance I_3.

An independent input U first flips Z conditionally. Then a reversible parity decoder transforms the register:

    (X,Y,Z) -> (X,Y,UZ) -> (X,Y,UXYZ).

The receiver reads the last bit, W=UXYZ. The other outputs and U remain in the full model. Every transformation is bijective conditional on U. There is no deletion of global information and no reward function.

With the parity relation present, XYZ=+1, so W=U. Without that relation, XYZ is a fair random sign and W is independent of U.

The exact general response is

    P(W=w | U=u,t) = (1+t u w)/2.

Thus the total variation between the two input-conditioned output laws is |t|. With a physical fair input source, the best recovery probability is (1+|t|)/2. Negative t reverses the encoding orientation without reducing its recoverable information.

| Initial dependency t | Initial covariance score, beta=1 | Receiver separation | Best input recovery | Input-output mutual information, bits |
| --- | ---: | ---: | ---: | ---: |
| 0 | 2.079442 | 0 | 1/2 | 0 |
| 1/2 | 2.079442 | 1/2 | 3/4 | 0.188722 |
| 1 | 2.079442 | 1 | 1 | 1 |

This establishes a distinction in available conditional responses. It does not assign a moral reward to transmitting a bit.

## 2. Why this is more than choosing one favorable gate

Every output bit of an eight-state reversible permutation is a balanced Boolean function: four input states give +1 and four give -1. Every such function also has a reversible extension. There are exactly choose(8,4)=70 distinct functions, and the code constructs and tests an explicit extension for all of them.

For a balanced readout f, define

    c_f = (1/8) sum_{x,y,z} xyz f(x,y,z).

Its receiver law is

    P(W=w | U=u,t,f) = (1+t c_f u w)/2.

The complete classification is:

| Readout class | Number of functions | Receiver separation |
| --- | ---: | ---: |
| Does not expose the dependency | 36 | 0 |
| Exposes it partially | 32 | abs(t)/2 |
| Exposes it maximally | 2 | abs(t) |

The two maximal functions are parity and its complement. The simple control W=UZ is in the zero-transfer class. These counts describe a finite set of operations; no uniform probability or normative weighting over decoder choices is assumed.

The underlying obstruction at t=0 is stronger than the enumeration. A uniform distribution on eight states is unchanged by every permutation, including permutations selected by the input. It therefore cannot acquire a receiver dependence on U through these reversible register operations. In the diagonal quantum description it is I_8/8, which is similarly unchanged under every unitary V acting on that register: V(I_8/8)V†=I_8/8.

At nonzero t, reversible permutations only rearrange four probabilities (1+t)/8 and four probabilities (1-t)/8. The total variation between any two such rearrangements is at most |t|: each of the eight pointwise probability differences is at most |t|/4. A subsequent readout cannot increase that distance. The parity device attains the bound.

No reset, fresh pure receiver bit, swap of the input into the receiver, or direct bypass wire is part of this interface. Adding those operations changes the problem. The compared devices have the same registers and allowed transformations; their initial preparation entropies differ. This is not a claim about matched preparation costs or universal superiority.

## 3. A precise failure of covariance closure

Even if we keep both means and covariance, the initial summaries agree for all t. Apply the same parity gate with fixed input U=+1. The resulting means and covariance are

    mean = (0,0,t)
    covariance = diag(1,1,1-t^2).

They now differ. Consequently, there is no single exact update on the initial mean/covariance summary that reproduces these outputs for every t. Equal summaries would have to update to different summaries under the same physical operation.

This is the concrete composition failure described abstractly by the primer's requirement q composed with F = F_bar composed with q. The failure belongs to this chosen compression. The full joint continuation object does update correctly.

There is also a particularly useful scope check: if U is physically fair and then ignored, the entire three-bit receiver register is uniformly distributed for every t. Even its complete unconditional state cannot reveal whether input information was transmitted. The full joint object retains the input-output correlation E[UW]=t. A continuation assessment therefore needs the conditional response relation, not just a snapshot of the resulting receiver state.

## 4. The existing formalism supplies the minimal repair

The observable functions

    1, X, Y, Z, XY, XZ, YZ

span seven dimensions on the eight possible register states. The future readout W, pulled back through the parity circuit, is XYZ. That is the missing eighth observable.

Adding XYZ completes an orthogonal product basis. For any distribution on these records, its product moments reconstruct the full law:

    P(x,y,z) = (1/8) sum over S of E[product of variables in S]
                                    times product of x_i for i in S.

The empty product is one. The code verifies orthogonality of the complete basis and exact reconstruction of all tested laws.

This matters to the research direction: XYZ is required because an actual permitted continuation reads it. It is not added because we decided that higher-order correlation deserves a bonus. The tester-closure machinery already tells us which distinctions a faithful representation must retain for this model.

## 5. Does a candidate richer probe notice the change?

Treat the two input-conditioned receiver laws as a response family. Their weights are one half because the input source is physically fair. For the declared similarity Z_ij=1-TV(P_i,P_j), the similarity-sensitive diversity candidate gives

    D2 = 1 / sum_ij p_i Z_ij p_j
       = 1 / (1-|t|/2).

It is 1 at t=0, 4/3 at |t|=1/2, and 2 at |t|=1. It notices the change from two identical responses to two perfectly distinguishable responses.

The exact probability-weighted covering profile agrees on the underlying separation. With centers in the response family, closed balls of radius epsilon, and allowed uncovered mass delta:

    N(epsilon,delta) = 1 if epsilon >= |t| or delta >= 1/2;
                      2 otherwise.

At any fixed meaningful resolution smaller than |t|, representing more than half of the fair input ensemble requires both response types. At t=0, one suffices at every resolution.

This is a positive discrimination test for these candidates, not their validation as global lushness. The linear similarity and physical interface remain specified choices. Changing the input distribution changes the probability-weighted profile; there is no canonical probability distribution over every counterfactual operation.

## 6. An independent operational check

The response comparison has a structural basis beyond the chosen diversity formula. Allow a receiver-only randomizer that cannot inspect U. A parity channel of strength t can reproduce one of strength s whenever |s|<=|t|: multiply W by an independent sign R with mean s/t, for t nonzero. The code verifies the resulting conditional laws exactly.

A receiver transformation cannot achieve the converse when |s|>|t|. For any binary stochastic postprocessing, write a=P(V=+1|W=+1) and b=P(V=+1|W=-1). The difference between the two input-conditioned probabilities is multiplied by a-b, whose absolute value is at most one. Receiver processing therefore cannot increase the separation.

This gives a conditional simulation order for this information-transfer capability. It is not an ordering of complete worlds, intrinsic worth, or all possible structural properties. In particular, the independent preparation has greater raw record entropy, while the correlated preparation has greater input-transfer capability under the stated operations. Those are different aspects of the object.

## 7. What is now justified?

The earlier probe showed an omitted relationship. This test shows that the omission can conceal a real difference in physically available conditional continuations. That is a legitimate structural ingredient for the lushness program to retain.

The original covariance summary cannot stand in for that full structure or support its exact continuation update. A scalar computed from the full object might still legitimately assign equal overall lushness to some different processes. No theorem here rules out such equality or proves that communication capability alone defines lushness.

The global object remains the target. The receiver restriction defines the tested physical relation; it does not declare the omitted source or other outputs nonexistent. An unrestricted observer can always inspect the source U itself. The claim concerns transfer into W, not an increase in global information under reversible dynamics.

The most concrete advance is therefore methodological: use actual continuation tests to determine sufficient structure, then evaluate candidate comparisons on it. This test supplies both an exact required observable and a finite response family on which the richer candidates detect a justified difference.

## Reproduction

Run `python run_test.py --out results` with Matplotlib installed. All probability laws, moments, circuit maps, distances, and discrete covering results use exact rational arithmetic. Entropies and plotting coordinates use floating point. No sampling, training, or network calls are used.

The final recorded run covered 17 values of t and all 70 balanced readouts. Calculation took approximately 0.19 seconds, and calculation plus figures approximately 0.71 seconds after imports. The verification ledger contains 30 categories and 3,596 individual consistency checks. These are implementation checks, not thousands of independent scientific findings.

Files include exact example joint laws, all reversible decoder maps, response and covering CSVs, code and environment provenance, figures, and the model specification. `MANIFEST.json` records SHA-256 checksums.

This applies the primer's established consequence, composition, and tester-closure constructions. The diversity formula is the previously discussed order-two similarity-sensitive candidate of Leinster and Cobbold; its application here uses the explicit similarity above. The underlying reversible information-processing facts are elementary, and no novelty or ethical theorem is claimed.
