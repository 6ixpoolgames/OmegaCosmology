# Tests

Add tests for concrete risks in new model and descriptor implementations. The existing exact baseline is reproduced by scripts/run_baseline.py.

Do not add a large test suite for the document scaffold or use a count of tests as evidence for the framework's moral conclusions.
