# Probe specification

**ID / date:**  
**Status:** proposed / running / completed / rejected / unresolved  
**Question:**  
**Related source and prior result:**  
**Why this probe adds information:**

## Intended object and translation

Describe the motivating distinction in ordinary language. Specify what the model retains, omits and assumes. Say whether any valuer, generativity, identity or preference criterion is supplied.

## Complete finite model

List state space, component structure, initial state, laws, instruments, physical control/resource semantics, records, temporal scope, environmental memory and allowed composition.

## Compared structures

List the action-conditioned objects. State what is held fixed and what changes. For process distances, specify matched types and the common tester family. For probabilities, identify the implemented instrument/policy; do not silently average over alternative controls.

## Candidate descriptor

Give an exact definition. Identify whether it is the full object, a sufficient representation for a scope, or a lossy diagnostic. Describe coordinate transport and known blind spots. Do not supply an ethical ranking unless that is the explicit separate question.

## Predictions and failure conditions

State what would distinguish the hypotheses and what would reject the candidate. Separate mathematical invariance requirements from hoped-for philosophical behavior.

## Method and budget

Arithmetic, enumeration/optimization method, limits, expected complexity, seeds if stochastic, and the reason for any added dependency.

## Evidence

Command, code revision/hash, outputs, exact witness or certificates, numerical error/bounds, and tests that address concrete risks.

## Result

- Structural finding:
- Interpretation:
- Unresolved bridge:
- Relation to prior work:
- Counterexamples or rejected alternatives:
- Next warranted step:
