#!/usr/bin/env python3
"""Verify the original handoff files against MANIFEST.json.

Additional local files are allowed. Changed, missing, unsafe or duplicate
manifest entries fail. The manifest is an integrity inventory, not a signed
authenticity certificate.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import sys


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    errors = []
    seen = set()
    for row in manifest["files"]:
        name = row["path"]
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or name in seen:
            errors.append({"path": name, "error": "unsafe or duplicate entry"})
            continue
        seen.add(name)
        path = root.joinpath(*relative.parts)
        if not path.resolve().is_relative_to(root):
            errors.append({"path": name, "error": "path escapes package"})
            continue
        if not path.is_file():
            errors.append({"path": name, "error": "missing file"})
            continue
        data = path.read_bytes()
        if len(data) != row["bytes"]:
            errors.append({"path": name, "error": "size mismatch"})
        if hashlib.sha256(data).hexdigest() != row["sha256"]:
            errors.append({"path": name, "error": "digest mismatch"})
    report = {
        "status": "passed" if not errors else "failed",
        "checked_files": len(seen),
        "errors": errors,
        "scope": "packaged bytes; not mathematical or philosophical validation",
    }
    print(json.dumps(report, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
