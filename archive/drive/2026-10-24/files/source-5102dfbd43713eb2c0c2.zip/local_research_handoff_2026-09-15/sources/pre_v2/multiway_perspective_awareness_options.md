# Multiway Structure, Perspective, and Awareness: Options for Formal Development

## Assessment

The proposed picture has a viable mathematical development path. Its strongest organizing idea is to distinguish a completed structure of possibilities from the perspectives available within it, while leaving the relationship between perspective and phenomenal awareness open. This permits several interpretations to share a structural core and makes their additional commitments inspectable.

The synthesis becomes more coherent when it separates three questions: what continuations the structure supports, what distinctions a perspective retains, and what is experienced. It becomes more holistic when it connects these questions to agency and the consequences of changing the conditions of future agency. Neither achievement, by itself, establishes a new physical theory or explains why anything is conscious. The substantive opportunity is to identify constraints between these layers that competing interpretations must satisfy.

The recommended foundation is a **multiway structure with explicit history semantics and a family of perspectival maps**. Quantum dynamics should enter through a specified adapter. Phenomenal coupling should remain an independently stated correspondence, with stronger versions compared rather than silently installed as definitions. Alpha can remain an optional generalization beyond the particular structure under study.

Three findings determine the recommendation:

1. **Present sameness does not settle future sameness.** Two occurrences can support the same present observation—or, hypothetically, the same experience—while occupying different causal positions. A single quotient cannot safely serve simultaneously as a theory of experience, prediction, personal identity, and ethical consequence.
2. **There are substantial precedents for the central moves.** Wolfram supplies an observer-oriented multiway program; Page supplies a framework centered on individual conscious perceptions; histories approaches supply tools for quantum alternatives and records. Their assumptions differ, so combining them requires an explicit interface.[^1][^2][^3]
3. **The repository already contains important safeguards.** Coherent path lifting, coarse/fine nonreflection, coupling information beyond marginals, and controlled consequences are established project groundwork. Rediscovering these in new notation would add little.[^4][^5][^6][^7]

The highest practical return for Gradient Ethics (GE) is likely to come from the interface between perspective and **action-dependent continuations**. That work can proceed while phenomenal coupling and the ultimate ontology remain unresolved. The cosmological account gains a disciplined architecture; GE gains clearer conditions under which an approximation preserves the futures it claims to assess.

## 1. Commitments worth preserving

The following is a proposed specification of the research program, rather than a claim that its ontology is established.

| Commitment | What it licenses | What remains open |
|---|---|---|
| Structure first | Study a completed object containing possibilities and their relations. | Whether every represented possibility exists physically or is lived. |
| Multiway organization | Represent branching, merging, alternative continuations, and path dependence. | What nodes and edges mean in a particular physical realization. |
| Perspective as an adapter | Different interfaces retain different distinctions in the same structure. | Which adapters are physically realizable, phenomenally relevant, or useful for a task. |
| Present awareness | Experience need not carry an additional memory of microscopic provenance. | Whether its physical support is instantaneous, temporally extended, or relational. |
| Open phenomenal coupling | Compare constitutive, emergent, and awareness-first interpretations. | A correspondence law, its causal role, and its empirical consequences. |
| Optional Alpha | Generalize beyond a selected universe or rule system when useful. | Whether that generalization describes reality. |
| Agency within the block | Actions change which continuations are accessible from a position. | An adequate account of interventions, self-modification, and counterfactual comparison. |

A completed graph can contain temporal order and causal asymmetry without an external process that makes the graph come into existence. Conversely, describing a graph as completed does not explain the arrow of time, the stability of records, or the apparent continuity of experience. Those require additional structure or an argument about the observers admitted by it.

Likewise, “awareness is present” need not mean “a dimensionless instant of neural activity suffices.” A present experiential occurrence could depend on an extended physical process while containing no awareness of the process's complete microhistory. This distinction preserves the intuition without choosing a neuroscience theory prematurely.

## 2. What is already in Omega

The relevant repository notes were examined at commit `cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88`. These are internal theoretical notes and finite-model investigations; their presence is not independent empirical validation.

| Existing work | Consequence for the next construction |
|---|---|
| **Alpha independence and presentation-native repair** distinguishes presentation-level constructions from claims about a substrate. | Keeping Alpha optional is consistent with existing groundwork. Avoid deriving a feature from a chosen presentation and then declaring the substrate independently confirmed.[^8] |
| **Coarse/fine nonreflection** shows why preservation of coarse distinctions need not preserve finer ones. | A stable experiential or observational description cannot certify preservation of every causally relevant distinction.[^5] |
| **Marginal coupling nonfactorization** compares different joint structures with identical marginals. | Weights assigned to individual experiences cannot determine a stream or a joint history without further information.[^6] |
| **Finite deformer profile checkpoint** already requires coherent path lifting and addresses stochastic lumpability or explicit memory. | A new quotient counterexample is explanatory reuse, not a new project result.[^4] |
| **Same coarse bisimulation, different consequence profile** demonstrates dependence on the declared observational panel. | Behavioral equivalence must specify which consequences and interventions it preserves.[^7] |
| **Observer loop closure and sound update** distinguishes observing, acting, and maintaining a feedback channel. | An observer quotient alone cannot establish agency, valuerhood, or standing.[^9] |

The older connection-like coarse-graining investigation also anticipates the concern that apparent richness can be produced by arbitrary labels or by retaining distinctions that do not support viable futures. Its entropy-based candidate should be treated as historical exploration, not as a binding definition of lushness.[^10]

The main repair needed now is therefore an explicit separation of roles, followed by a small number of integrations that answer questions the existing work leaves open.

## 3. Comparative map of the options

These are complementary tools and, in some cases, alternative foundations. They should not all be adopted at once.

| Option | Strongest contribution | Additional commitment or limitation | Recommended role |
|---|---|---|---|
| Multiway graph with retained histories | Branching, merging, provenance, accessibility | Connectivity supplies neither probabilities nor phenomenal interpretation | Core representation |
| Bisimulation and coalgebra | Conditions for replacing a system by a behavior-preserving quotient | Preservation is relative to a specified system type and observable interface | Structural correctness tools[^11] |
| Computational mechanics and input-output causal states | Compress histories while preserving future predictions and responses to inputs | Requires a process model, an observation alphabet, and relevant statistical assumptions | Main practical bridge to GE[^12][^13] |
| Decoherent histories and quantum measure | Treat quantum alternatives at the level of histories, with interference retained | Requires dynamics, boundary data, and consistency conditions | Preferred quantum histories adapter[^3][^14] |
| Quantum process tensors | Represent multitime intervention statistics and hidden environmental memory | Assumes quantum operational structure and a defined system/environment interface | Quantum dynamics testbed[^15] |
| Categorical rewriting and ZX semantics | Compose and compare quantum processes through diagrammatic rewrites | A proof rewrite is not automatically a physical transition | Add when compositional quantum examples require it[^16] |
| Page-style awareness measures | Relate a quantum state to a measure over conscious perceptions | Awareness operators remain unspecified; experience weights do not supply personal continuity | Main phenomenal comparison model[^2][^17] |
| Müller’s observer-state foundation | Starts with observer states and algorithmic prediction | Adds a universal-induction foundation; observer states are not identified with consciousness | Separate foundational fork[^18] |
| IIT or other empirical consciousness models | Supply stronger, potentially testable restrictions on phenomenal correspondence | Substantial extra commitments about the substrate and its organization | Optional candidate constraints, not the core[^19] |

Two further tools become useful if particular difficulties arise. **Event structures** distinguish causal dependence, conflict, and concurrent events; their probabilistic and quantum extensions provide alternatives to representing every execution ordering as a distinct fundamental history.[^20] **Contextuality sheaves** formalize when compatible descriptions in overlapping measurement contexts cannot be assembled into one context-independent assignment.[^21]

My assessment is that the first three rows should organize the initial formalism. Histories and process tensors then provide two related quantum realizations. Page supplies a substantive comparison for phenomenal coupling, while Müller and IIT should remain separately labeled alternatives.

## 4. The structural core

### 4.1 Define what the graph represents

For a first mathematical presentation, use a labeled directed multigraph

$$
G=(V,E,s,t,\ell)
$$

with a declared family $\mathfrak H$ of admissible histories. Here $s,t$ give edge endpoints and $\ell$ records relevant transition labels. Labels might represent actions, environmental changes, or rewrite applications. They acquire a physical interpretation only in an instantiated model.

Using a multigraph allows different transitions between the same endpoints to retain their provenance. Whether those transitions are physically distinct, alternative derivations of the same description, or redundant encodings must be declared. The admissible-history family also permits constraints that cannot be read from neighboring nodes alone.

The first implementation can be finite or countable. That is a tractability choice for the model. It should not become an unsupported conclusion that reality is discrete, computable, or exhausted by that implementation.

A self-modifying agent presents no contradiction with a fixed completed structure if its current rule, memory, and action interface are included in the state description. Transitions can modify that internal rule. The global representation then contains changes to the agent's effective landscape. It does not require the completed object itself to be rewritten from an external time.

### 4.2 Keep observer positions distinct from experience types

Let a pointed history specify a history prefix and an observer interface at its current position. Write $z\in Z$ for such a position, and let

$$
\pi_o:Z\longrightarrow P_o
$$

be the perspective associated with interface $o$. This map describes what distinctions the interface retains. It is initially an observational or functional object. Calling its output conscious would add a psychophysical assumption.

If the current physical node contains everything relevant to that interface, $\pi_o$ may factor through the endpoint. Otherwise, retaining a history or an extended neighborhood prevents an unjustified sufficiency assumption. History dependence in the mathematical description does not imply that the observer consciously remembers that history.

Two positions can have the same $p\in P_o$ while differing in their environment, available controls, or future consequences. They remain distinct positions. Even a later identification of their phenomenal character would not make them one physical occurrence or establish that they are the same continuing subject.

This suggests an important reading of the original intuition: **a present perspective may locate an equivalence class of compatible positions, rather than a unique microscopic route into the present**. Additional evidence, causal constraints, or a phenomenal law may narrow that class. The coarse-graining map alone need not do so.

### 4.3 Preserve coherent projected histories

For an admissible history $h$, consider the sequence of its perspectival descriptions. The projected history language is

$$
\mathcal L_o=
\left\{\bigl(\pi_o(h_{\leq0}),\ldots,\pi_o(h_{\leq n})\bigr):
h\in\mathfrak H\text{ has length }n\right\},
$$

where the observer occurrence at each prefix is understood to be specified. An evolving observer interface can be included in that specification; a persisting metaphysical subject is not assumed.

The safe object is this set of projected histories, or a representation preserving it. A graph formed merely by merging nodes with the same output can permit walks assembled from incompatible fine representatives. Such walks need not belong to $\mathcal L_o$. Omega already records this issue and related lifting requirements.[^4]

For example, take edges

$$
r\to a,\qquad a\to b_1,\qquad r\to b_2,\qquad b_2\to c,
$$

and identify $b_1,b_2$ as $B$. The quotient permits $R\to A\to B\to C$, although no original history follows that sequence. All original nodes are reachable; the error is the unnoticed switch between representatives of $B$.

This finite example was checked by enumeration. Its purpose is to illustrate an existing constraint, not to count as evidence for the cosmology. Infinite histories require further care: having some lift for every finite prefix need not provide one compatible infinite lift without suitable assumptions.

### 4.4 Use distinct equivalences for distinct questions

| Equivalence | Question it answers | What it does not automatically preserve |
|---|---|---|
| Present observational equivalence | Does the current interface return the same description? | Future predictions or environmental conditions |
| Phenomenal equivalence | Is the experiential character the same, under a specified coupling hypothesis? | Occurrence count, causal position, or personal identity |
| Predictive equivalence | Are distributions of specified future observations equal? | Responses to interventions absent from the model |
| Controlled equivalence | Are relevant future responses equal under the allowed controls or policies? | Unrepresented consequences or newly available controls |
| GE-relevant equivalence | Are the declared distinctions concerning viable future valuation preserved? | The correctness or completeness of those ethical distinctions |

The definition of a predictive state can be made precise using computational mechanics: histories are grouped by their conditional distributions of future observations. Its minimality results concern the predictive task under the paper's process assumptions. They do not identify a conscious subject.[^12]

The input-output extension is especially relevant. An ε-transducer compares output futures while accounting for future inputs. This avoids treating equivalence under one habitual input sequence as equivalence under every experiment. Interpreting inputs as interventions still requires a model in which those inputs are controllable, rather than arbitrary conditioning on correlated events.[^13]

For a finite controlled Markov model, a sufficient condition for an exact state aggregation is that, whenever $q(x)=q(x')$,

$$
\sum_{y:q(y)=b}P(y\mid x,a)
=
\sum_{y:q(y)=b}P(y\mid x',a)
$$

for every allowed action $a$ and aggregate state $b$. Observable labels and any quantities claimed to be preserved must also agree. If the condition fails, retain hidden state or history, or state an approximation error. This is a standard aggregation condition already anticipated by the repository's lumpability checks.[^4]

Bisimulation provides another route when the intended behavior is transition-based rather than probabilistic. The advantage of coalgebra is a common language for several kinds of systems and their behavior-preserving maps. Its generality does not eliminate the need to specify which behavior the system representation includes.[^11]

## 5. The quantum options

### 5.1 Histories provide the most natural interface

The histories approach describes alternatives through sequences of quantum propositions. In a conventional realization, a history has a class operator

$$
C_\alpha=P_{\alpha_n}(t_n)\cdots P_{\alpha_1}(t_1),
$$

and the decoherence functional is

$$
D(\alpha,\beta)=\operatorname{Tr}(C_\alpha\rho C_\beta^\dagger).
$$

When interference between distinct members of a family is negligible in the appropriate sense, its diagonal weights can be used as approximately additive probabilities. Hartle's records-based formulation connects this consistency to physical records and explicitly assumes the Born rule for those records.[^3]

This is an attractive adapter because it takes alternative histories seriously without requiring each microscopic path to have an ordinary classical probability. Sorkin's quantum-measure program makes the histories orientation still more explicit: its measure permits interference and obeys a different additivity structure from classical probability. It provides a route to discussing histories without making state vectors the initial ontology.[^14]

For this project, the adapter must specify which graph histories correspond to quantum histories, how amplitudes or class operators are assigned, and what physical records the observer interface can access. Merely renaming edges “quantum transitions” supplies none of these data.

Within a declared quantum history event space, a coarse event map $f$ can transport a decoherence functional by

$$
D_o(B,C)=D(f^{-1}(B),f^{-1}(C)).
$$

This construction retains interference between coarse alternatives. Treating the resulting diagonal as an ordinary probability measure on arbitrary events would require additional consistency conditions. The formula is a proposed interface construction; it is not a derivation of a quantum law from the multiway graph.

Hartle's discussion of quantum pasts is also relevant: present data do not generally select a unique fine-grained quantum past, and retrodiction depends on the state, dynamics, and history framework. A physically encoded memory is part of present data, not privileged access to a uniquely specified microscopic genealogy.[^22]

### 5.2 Decoherence and perspectival equivalence have different jobs

Environmental decoherence concerns the suppression of interference for specified degrees of freedom through their correlations with an environment. It helps explain stable classical descriptions but does not, by itself, select a single experienced outcome or explain phenomenality.[^23]

Thus “the only orientation compatible with awareness is decoherence” can become a research hypothesis only after distinguishing two claims:

1. Physically sustainable perspectives require certain stable records or robust correlations.
2. Those structures are sufficient, necessary, or constitutive for phenomenal awareness.

The first concerns observer dynamics. The second is a proposed coupling law. Their coincidence would be a result to establish. Defining them as the same object would hide the question.

Quantum Darwinism offers a concrete candidate mechanism for the first claim: selected information about a system is recorded redundantly in environmental fragments, making it accessible to multiple observers.[^24] Relational quantum mechanics offers another interpretation of perspective: Di Biagio and Rovelli distinguish facts relative to interactions from facts stable enough that this relativity can effectively be ignored.[^25] Neither needs a specifically human observer as a mathematical primitive.

For the combined framework, these alternatives are useful controls. If the same predicted observations result with and without awareness playing an explanatory role, the observations establish compatibility with the awareness reading rather than favoring it uniquely.

### 5.3 Process tensors preserve hidden temporal dependence

Pollock and colleagues formulate quantum memory operationally using responses to interventions at multiple times. Their process-tensor approach captures dependencies that a sequence of local density matrices can miss. In their illustrative SWAP construction, information can leave a system, persist in its environment, and later return even though the intermediate system state does not reveal it.[^15]

This addresses a central ambiguity in “forgetful awareness.” Current experiential or local physical sameness may coexist with different later consequences. A mathematical model can keep the awareness description present-centered while retaining the wider process that governs continuation.

Use this option when examining actual quantum experiments or when a proposed present-state description claims to predict its own future. It is less suitable as the unrestricted ontology because it already presumes a quantum system interface and operational machinery. Its value is a precise test of whether that interface has discarded relevant memory.

### 5.4 Multiway quantum constructions are real options, with specific premises

Gorard, Namuduri, and Arsiwalla connect multiway rewriting to categorical quantum information through ZX-calculus and extended hypergraph rewriting. This provides a concrete compositional bridge.[^16] Its application requires distinguishing a graph of alternative **descriptions or proofs** from a graph of alternative **physical histories**. Two diagrams related by a sound rewrite may denote the same process. Counting those descriptions as additional physical futures would need a separate justification.

A December 2025 preprint by Dündar, Arsiwalla, and Elshatlawy constructs quantum operators and gates using particular decorated multiway rewriting systems. Its edge weights are chosen to impose unitarity. This is a useful representation result and a possible source of worked quantum adapters; it does not show that an arbitrary unweighted multiway topology produces quantum mechanics.[^26]

An elementary calculation makes the missing information visible. For the same two-path circuit topology,

$$
H\begin{pmatrix}1&0\\0&e^{i\phi}\end{pmatrix}H|0\rangle
$$

gives output probabilities

$$
P(0)=\cos^2(\phi/2),\qquad P(1)=\sin^2(\phi/2).
$$

Changing the phase changes the result without changing the connectivity. The probabilities were checked directly for $\phi=0,\pi/2,\pi$. A graph could encode the phase in labels or other structure, but the encoding and composition rules then belong to the model's stated content.

### 5.5 Delayed-choice erasure is a consistency check

The original delayed-choice eraser experiment concerns correlations between detections and the availability of which-path information.[^27] The relevant distinction is between the unsorted detection statistics and subensembles selected using the other detector's results. The delayed choice does not alter the earlier unsorted record; fringe and complementary fringe correlations appear in appropriately conditioned data.[^28]

A two-qubit analogue makes the distinction transparent. For $|\Phi^+\rangle=(|00\rangle+|11\rangle)/\sqrt2$, measuring the first qubit in the $X$ basis gives equal marginal probabilities whether the second is measured in $Z$ or $X$. The joint distributions differ: the former has four equally weighted outcomes; the latter has two perfectly correlated outcomes. Direct matrix calculation verifies both statements.

Any proposed quantum adapter should reproduce this separation of marginal and conditional statistics. Doing so would demonstrate consistency with the example. Evidence for a special role of awareness would require a further prediction that differs from the awareness-independent model.

## 6. Phenomenal coupling: the genuine choices

### 6.1 Start with a correspondence before choosing its direction

Let $\mathcal A$ be a provisional space of experiential descriptions. The weakest formal addition is a relation

$$
K\subseteq Z\times\mathcal A.
$$

It states which observer positions and experiential descriptions are compatible. It does not yet determine whether experience is generated, selected, constituted, or fundamental. Nor does a correspondence relation alone explain why its related items occur.

Suppose one instead writes

$$
K(z,a)\iff\kappa(\pi_o(z),a).
$$

That factorization is a substantive assumption: the chosen perspective is **phenomenally sufficient**. It excludes phenomenal dependence on distinctions erased by $\pi_o$. This might be correct, but it should be a named hypothesis with alternatives, including dependence on an extended process or on additional relational structure.

This yields several distinct development choices:

| Coupling choice | What would be specified | Main unresolved burden |
|---|---|---|
| Open correspondence | A family of admissible relations $K$ | Too little restriction gives little explanatory or predictive content |
| Structural sufficiency | Experience determined by specified structural features | Justifying both the features and their sufficiency |
| Constitutive identity | The relevant organized structure is the experience | Explaining which organization and why the identity claim is warranted |
| Awareness-first compatibility | Experiential descriptions constrain admissible perspectives or structures | A selection or consistency rule, especially when many structures fit |
| Additional psychophysical dynamics | Experience enters transition or intervention laws | A coherent dynamics and a discriminating empirical consequence |

Leaving the direction open is legitimate at the architectural stage. Claiming that every choice has already become one explanatory theory would be premature. A direction-neutral relation also cannot establish causal neutrality: whether awareness affects the dynamics is a separate commitment.

### 6.2 Page is the closest developed precedent for the present-experience move

Page's Sensible Quantum Mechanics associates measures with complete conscious perceptions while keeping the quantum state noncollapsing. It does not take enduring minds or fundamental links between successive perceptions as basic. This is a close precedent for present awareness without an additional awareness of which microscopic route produced it.[^2]

In the later exposition, a set $S$ of perceptions receives measure

$$
\mu(S)=\sigma[A(S)],
$$

or $\operatorname{Tr}(\rho A(S))$ in a density-operator realization. The awareness operators are positive; the measure need not be a normalized probability distribution over all experiences. Their detailed form remains unspecified. Page also discusses models in which multiple physical states correspond to the same perception, without making that illustrative choice compulsory.[^17]

This provides a usable comparison model while exposing the remaining work: specify the correspondence, justify a measure or conditional typicality rule, and explain any claim about experiential continuity. A measure over experiential descriptions is not automatically a law assigning the next experience to a continuing person.

The distinction between an experience **type** and its physical **occurrences** must also remain explicit. Combining the weights of several occurrences with identical character does not establish numerical identity between those occurrences. GE may need their different causal capacities even where a phenomenal description does not distinguish them.

### 6.3 A tempting coupling formula has a hidden restriction

Consider the candidate construction

$$
E_a=\sum_p\kappa(a\mid p)R_p,
$$

where the $R_p$ are mutually orthogonal projectors onto present structural alternatives. This is a sensible restricted model: classify the structure by $p$, then assign an experiential label through a stochastic channel.

But it has an immediate consequence:

$$
[E_a,E_b]=0
$$

for every $a,b$, because all the operators are diagonal in the same projector decomposition. It therefore builds a common classical classification into the coupling. Calling it a fully general quantum account of awareness would be inaccurate. This is an algebraic diagnosis of the proposed formula, not a claim that awareness requires noncommuting operators.

There are three honest options: retain it as a restricted model, allow more general positive operators, or postpone operator-valued coupling until a physical realization requires it. The third is best for the broad core; the first is adequate for a clearly labeled finite example.

### 6.4 Present weights do not supply a stream

Consider two proposed joint distributions of experience labels at two positions:

$$
J_1=\begin{pmatrix}1/4&1/4\\1/4&1/4\end{pmatrix},
\qquad
J_2=\begin{pmatrix}1/2&0\\0&1/2\end{pmatrix}.
$$

Both have marginal distribution $(1/2,1/2)$ at each position. Their temporal correlations are different. This is the same mathematical distinction already used in Omega's marginal-coupling note; the matrices were checked directly.[^6]

Consequently, neither a set of possible present experiences nor a measure on that set determines a unique experiential stream. A stream might instead be reconstructed from physical records, specified by a joint law, or treated as an emergent relation among occurrences. Those options have different commitments about identity. None requires answering the full metaphysical identity question before studying local continuations.

### 6.5 Other approaches sharpen particular choices

Wolfram's observer theory emphasizes bounded observers, equivalencing, and the persistence of an observer's description across underlying computation. It is valuable for articulating the adapter move. Its observer concept is primarily computational and does not supply a settled phenomenal coupling law. The wider claims about deriving physics should be assessed by their particular constructions and assumptions.[^1]

Müller offers a more radical alternative: observer states and algorithmic prediction precede the inferred external world. The paper explicitly avoids identifying its observer states with consciousness. Adopting this route would change the foundation of prediction, rather than simply add another label to the existing graph. Its algorithmic probabilities should not be combined with Born or awareness measures without an argument connecting them.[^18]

IIT supplies a stronger kind of psychophysical proposal, using postulates about intrinsic causal organization to specify a conscious substrate and its experiential structure.[^19] It could constrain $K$, but doing so would import its substantive assumptions. The 2025 COGITATE comparison found results supporting some predictions and challenging key tenets of both IIT and global neuronal workspace theory; it does not provide a settled empirical coupling law to adopt.[^31]

These approaches are useful because they make different bets. The broad architecture should retain the capacity to express those bets without presenting their disagreement as already resolved.

## 7. What the completed picture still has to specify

### Possibility, occurrence, weight, and value

Four assignments must be kept distinct:

| Assignment | Question |
|---|---|
| Structural admissibility | Is this history or configuration permitted by the model? |
| Phenomenal occurrence | Does an experiential occurrence correspond to it? |
| Measure or credence | How should experiences, outcomes, or self-locations be weighted? |
| Evaluation | Which available continuations are better under the proposed account of value? |

The existence of a continuation does not determine its weight. A weight does not determine its value. A description of all admissible possibilities does not decide whether all are lived. These are dependencies the framework can investigate, rather than distinctions it must erase.

Sebens and Carroll offer an Everettian probability proposal based on self-locating uncertainty and an epistemic separability principle. It is an option for connecting a global quantum state to local credence, with an explicit extra principle.[^29] Kent disputes the self-locating argument.[^30] This disagreement is a reason to identify the chosen probability assumptions, not a reason to abandon the block framework.

The same discipline applies to quantum-immortality-like readings. A surviving continuation being structurally available does not establish that continued experience has probability one, or that a particular subject has that continuation. A probability claim needs a measure; a personal-continuation claim needs a relation between occurrences. Conditioning on surviving experiences does not settle either claim for an unconditioned decision.

Likewise, exhaustive knowledge of an infinite structure would not select a unique measure merely through knowledge of its membership and connectivity. If the measure is part of the world's additional structure, omniscience would include it. If it has not been specified, different measures can remain mathematically possible. This is a question of what the object contains, distinct from whether a finite agent can compute it.

### A global quantum structure need not be a global classical assignment

Abramsky and Brandenburger formalize contextuality through the failure of suitable local measurement statistics to admit a single global, context-independent assignment reproducing them.[^21] This does not rule out a global quantum description. It restricts how local descriptions can be glued together.

The project should therefore avoid assuming that every hypothetical measurement outcome can be written onto a single classical history merely because the structure is complete. A multiway representation may instead retain measurement contexts, amplitudes, and compatibility relations. The “god's-eye” object can be richer than a classical list of all locally imagined facts.

This also qualifies the image of one locked past with a fan of futures. Stable present records can strongly constrain retrodiction. That does not require a unique fine-grained genealogy across every possible quantum description. The asymmetry between reliable records and open anticipation needs a physical or observer-selection account; completedness alone does not supply it.

## 8. What this offers Gradient Ethics

GE needs a representation of viable future valuation and of how actions affect its conditions. It does not immediately need a unique answer to which quantum interpretation is correct. The open-coupling architecture allows practical work to proceed without pretending that observerhood, agency, consciousness, and valuerhood are interchangeable.

The useful mathematical bridge is a **controlled continuation profile**. As a provisional descriptor, write

$$
\mathcal C_o(z)=
\left\{
\operatorname{Law}(Y_{\mathrm{future}}\mid z,\operatorname{do}(u)):
u\in\mathcal U_{\mathrm{admissible}}(z)
\right\}.
$$

Here $Y$ records declared future distinctions, and $u$ denotes an admissible control strategy, potentially using feedback. The expression presumes an intervention model and a probability law. In a purely nondeterministic graph, one would instead retain sets of reachable output histories. Neither representation gets probabilities by counting paths automatically.

This is a proposed analytical interface, **not a definition of lushness**. It gives somewhere to represent the distinction between sterile repetition and generative capacity: different present positions may support different sets of achievable continuations, different opportunities to learn or recover, and different capacities to maintain the channels on which later choices depend.

The observation interface matters. If $Y$ records only a fixed task score, it can miss the loss of capacities needed for future valuation. If it records every microscopic distinction indiscriminately, it can mistake irrelevant variation for additional value. This is precisely why the repository's consequence panels and coarse-graining safeguards are useful.[^7][^10]

Three aspects of the broader intuition can be retained without settling a scalar measure:

1. **Consequential diversity.** Two branches count as different for a declared comparison when their difference survives into relevant consequences. Duplicating notation or inserting redundant rewrite steps should not manufacture richness. Physical duplication can matter when it changes resources, interactions, or attainable futures.
2. **Regenerative capacity.** A position can be assessed partly by whether it preserves or restores the ability to reach a wider range of viable continuations. This must include the environment and maintenance of the action interface, not merely the agent's present menu.
3. **Perspective-sensitive comparison.** Branches can be compared from a specified position, over declared horizons and uncertainties, without first assigning one total value to the entire multiverse.

A scalar notion of volume remains possible. Before choosing one, its intended invariances need to be stated: which relabelings, refinements, duplicate representations, and changes of observation scale leave the assessment unchanged? Those requirements can rule out bad candidates without legislating the final answer. Probabilistic weight, geometric volume, reachable-set size, and ethically relevant richness may be related in a model, but their equality would be a further result.

This preserves the practical ambition. A system that retains the capacity to discover better policies, recover from model error, and revise its own interfaces may outperform one that commits irreversibly on a mistaken abstraction. That is a conditional capability hypothesis worth testing. It requires environments where retained flexibility pays for its costs, a fair comparison of resources, and competent baselines. No graph formalism alone establishes that corridor preservation always wins a race.

The persistence filter belongs in those dynamics: different policies can differentially sustain the processes that continue acting and valuing. The filter need not make persistence an explicitly represented goal. But differential persistence still does not guarantee increasing richness, moral concern, or a binding reason for every optimizer to preserve other valuers.

Most importantly, observational or phenomenal sameness should not automatically erase separate causal positions from GE's account. A single integrated controller and a coordinated plurality can be compared through their continuation capacities without deciding their merit by the number of named identities. An excisive controller remains concerning because of what it closes off under the evaluation, rather than because its organizational label is “singleton.”

## 9. Recommended development sequence

### First: write the interface specification

The immediate deliverable should be a short specification distinguishing the structural object, history semantics, observer interface, dynamics, phenomenal correspondence, and evaluative target. For every component, identify whether it is assumed, constructed, measured, or left open.

The main acceptance criterion is fidelity: none of the unresolved questions should be answered merely because a convenient data type requires an answer. In particular, do not install a universal entropy objective, a fixed personal-identity relation, or a unique phenomenal quotient by default.

### Second: reuse the existing finite machinery for one meaningful comparison

The next useful finite model should compare positions that share a present observation but differ in their capacity to maintain or recover their future action interface. Retain feedback, environmental dependence, and provenance. Compare an observational quotient with a controlled continuation description using Omega's existing deformer and consequence machinery.[^4][^9]

The question is whether the latter preserves a distinction that materially changes a decision, and what information or computation that preservation costs. A successful result would establish that particular gain under stated conditions. It would not establish a universal theory of value.

Before building the example, check the existing cases for the same distinction. If the repository already supplies it, use that result and improve the account of its scope. Additional generated cases are justified only by a concrete unresolved failure mode.

### Third: build one quantum realization

Use either a histories adapter or a process tensor for a small interference-and-record model. State the mapping from multiway events to physical operations. It should reproduce ordinary interference, the distinction between conditional and marginal eraser statistics, and the persistence of hidden memory when the environment retains it.

This model would answer whether the proposed interfaces can coexist coherently in a quantum realization. The elementary calculations in this report are checks on the ingredients, not a completed realization of the combined model.

### Fourth: compare phenomenal hypotheses on the same structure

Hold the physical model fixed and compare at least two candidate correspondences: for example, one depending on a present record and another depending on a specified extended process. Identify where they agree and disagree about experiential occurrence, weighting, or continuity.

If they make no different observable predictions, present them as distinct interpretations compatible with that model. A sharper empirical theory would require additional constraints. Even without empirical separation, identifying the exact extra assumptions would improve the philosophical account.

### Fifth: return to lushness through invariances and decision consequences

Only after the continuation representation is clear should a candidate richness measure be selected. Evaluate how it behaves under harmless changes of representation, changes in the horizon, hidden environmental dependence, and self-modification of the interface. These are more informative checks than constructing a world in which the preferred measure wins by definition.

The practical GE paper can use the best-supported finite result and explain its limits. The cosmological synthesis can describe the broader architecture and its open couplings. Linking the two does not require treating the speculative layers as prerequisites for every practical claim.

## 10. Final judgment

The combined picture earns its place as a research architecture because it organizes real distinctions: structure and perspective; present experience and historical provenance; local appearance and controlled consequence; physical possibility and phenomenal occurrence. The literature supplies substantial formal resources for each, and Omega already contains several of the safeguards needed to connect them.

The remaining opportunity is concentrated in the connections. A successful next step would show exactly which distinctions an observer-relative description must preserve for a declared causal or evaluative purpose, while allowing its phenomenal interpretation to remain open. That would be a concrete advance in the project's clarity and usefulness even if every mathematical ingredient is borrowed.

The strongest unresolved claim is that these constraints ultimately converge on the intended account of value and generative richness. The formal options identified here make that claim more inspectable. They do not yet establish the convergence.

## Sources

Sources were checked through 14 September 2026. Publication status is identified where material. The repository references are pinned to the examined commit. The review covered the cited notes and relevant log material; it was not a verification of every repository claim or a rerun of its formal proofs. The finite calculations described above check the stated examples only.

[^1]: Stephen Wolfram, [“Observer Theory”](https://writings.stephenwolfram.com/2023/12/observer-theory/) (2023). Author's programmatic exposition; particularly the discussion of equivalencing, bounded observers, and multiway systems.

[^2]: Don N. Page, [“Sensible Quantum Mechanics: Are Only Perceptions Probabilistic?”](https://arxiv.org/abs/quant-ph/9506010) (1995; substantive revised version 1997). Theoretical framework connecting conscious perceptions and quantum expectation values.

[^3]: James B. Hartle, [“Decoherent Histories Quantum Mechanics Starting with Records of What Happens”](https://arxiv.org/abs/1608.04145) (2016). Records-based construction; the Born rule for records is an explicit assumption.

[^4]: Omega repository, [“Finite Deformer Profile Checkpoint v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/omega_theory/finite_deformer_profile_checkpoint_v0.md). Existing finite-model scope, path-lifting safeguards, stochastic closure checks, and limits on agency claims.

[^5]: Omega repository, [“Coarse/Fine Nonreflection v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/omega_theory/coarse_fine_nonreflection_v0.md). Preservation and reconstruction limits under coarse maps.

[^6]: Omega repository, [“Marginal Coupling Nonfactorization v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/omega_theory/marginal_coupling_nonfactorization_v0.md). Identical marginals with distinct joint structure.

[^7]: Omega repository, [“Same Coarse Bisimulation, Different Consequence Profile v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/validation_results/baseline_witnesses/same_coarse_bisimulation_different_consequence_profile_v0.md). Dependence of behavioral equivalence on a declared consequence panel.

[^8]: Omega repository, [“Alpha Independence and Presentation-Native Repair v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/omega_theory/alpha_independence_and_presentation_native_repair_v0.md). Limits on inferring substrate claims from a chosen presentation.

[^9]: Omega repository, [“Observer Loop Closure and Sound Update v0”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/omega_theory/observer_loop_closure_and_sound_update_v0.md). Observation, interventions, feedback, and epistemic soundness.

[^10]: Omega repository, [“Connection-Like Relation as Coarse-Graining Admissibility”](repository://Omega/blob/cc4c89ca6552ce52cc5f7392e3b95f0c24dfdf88/docs/research_notes/primitive_branch/connection_like_relation_as_coarse_graining_admissibility.md). Historical exploration of transported distinctions and future plurality.

[^11]: J. J. M. M. Rutten, [“Universal Coalgebra: A Theory of Systems”](https://www.cs.cornell.edu/courses/cs6861/2024sp/Handouts/Rutten.pdf), *Theoretical Computer Science* 249, 3–80 (2000). Particularly bisimulation and quotient systems; DOI 10.1016/S0304-3975(00)00056-6.

[^12]: Cosma Rohilla Shalizi and James P. Crutchfield, [“Computational Mechanics: Pattern and Prediction, Structure and Simplicity”](https://arxiv.org/abs/cond-mat/9907176), *Journal of Statistical Physics* 104, 817–879 (2001). Predictive equivalence and causal-state minimality under the stated assumptions.

[^13]: Nix Barnett and James P. Crutchfield, [“Computational Mechanics of Input–Output Processes: Structured Transformations and the ε-Transducer”](https://arxiv.org/abs/1412.2690), *Journal of Statistical Physics* 161, 404–451 (2015). Future-input-conditioned equivalence for stochastic channels; DOI 10.1007/s10955-015-1327-5.

[^14]: Rafael D. Sorkin, [“Quantum Mechanics as Quantum Measure Theory”](https://arxiv.org/abs/gr-qc/9401003), *Modern Physics Letters A* 9, 3119–3127 (1994). Histories, interference, and generalized measure.

[^15]: Felix A. Pollock, César Rodríguez-Rosario, Thomas Frauenheim, Mauro Paternostro, and Kavan Modi, [“Operational Markov Condition for Quantum Processes”](https://arxiv.org/abs/1801.09811), *Physical Review Letters* 120, 040405 (2018). Operational memory criterion and the supplementary SWAP example.

[^16]: Jonathan Gorard, Manojna Namuduri, and Xerxes D. Arsiwalla, [“ZX-Calculus and Extended Hypergraph Rewriting Systems I: A Multiway Approach to Categorical Quantum Information Theory”](https://arxiv.org/abs/2010.02752) (2020 preprint). Multiway rewriting and categorical quantum-process semantics.

[^17]: Don N. Page, [“Mindless Sensationalism: A Quantum Framework for Consciousness”](https://arxiv.org/abs/quant-ph/0108039) (2001). Positive awareness operators, measures of perceptions, and illustrative correspondence hypotheses.

[^18]: Markus P. Müller, [“Law without Law: From Observer States to Physics via Algorithmic Information Theory”](https://arxiv.org/abs/1712.01826), *Quantum* 4, 301 (2020). Observer-state and universal-induction postulates; the text distinguishes its observer concept from consciousness.

[^19]: Larissa Albantakis and colleagues, [“Integrated Information Theory (IIT) 4.0: Formulating the Properties of Phenomenal Existence in Physical Terms”](https://arxiv.org/abs/2212.14787) (2022 preprint; published in *PLOS Computational Biology*, 2023). A substantive proposed psychophysical theory, not an established coupling law.

[^20]: Vítor Fernandes, Marc de Visme, and Benoît Valiron, [“Non-Deterministic, Probabilistic, and Quantum Effects through the Lens of Event Structures”](https://arxiv.org/abs/2408.14563) (2024 technical report). Soundness and adequacy of event-structure semantics for the specified execution models. Used here only to identify an available representation option.

[^21]: Samson Abramsky and Adam Brandenburger, [“The Sheaf-Theoretic Structure of Non-Locality and Contextuality”](https://arxiv.org/abs/1102.0264), *New Journal of Physics* 13, 113036 (2011). Obstructions to context-independent global descriptions of measurement statistics.

[^22]: James B. Hartle, [“Quantum Pasts and the Utility of History”](https://arxiv.org/abs/gr-qc/9712001), *Physica Scripta* T76, 67–77 (1998; preprint 1997). Retrodiction from present data within quantum histories.

[^23]: Maximilian Schlosshauer, [“Decoherence, the Measurement Problem, and Interpretations of Quantum Mechanics”](https://arxiv.org/abs/quant-ph/0312059), *Reviews of Modern Physics* 76, 1267–1305 (2005). Technical review of environmental decoherence and its interpretive limits.

[^24]: Wojciech H. Zurek, [“Quantum Darwinism”](https://arxiv.org/abs/0903.5082), *Nature Physics* 5, 181–188 (2009). Environmental proliferation of records and emergent classical accessibility.

[^25]: Andrea Di Biagio and Carlo Rovelli, [“Stable Facts, Relative Facts”](https://arxiv.org/abs/2006.15543), *Foundations of Physics* 51, 30 (2021). A relational account of stable facts and decoherence.

[^26]: Furkan Semih Dündar, Xerxes D. Arsiwalla, and Hatem Elshatlawy, [“Quantum Gates from Wolfram Model Multiway Rewriting Systems”](https://arxiv.org/abs/2512.20587) (December 2025 preprint). The construction uses decorated strings, action-dependent phases, and selected edge weights; see its discussion of imposing unitarity.

[^27]: Yoon-Ho Kim, R. Yu, S. P. Kulik, Y. H. Shih, and Marlan O. Scully, [“A Delayed Choice Quantum Eraser”](https://arxiv.org/abs/quant-ph/9903047), *Physical Review Letters* 84, 1–5 (2000). Original experiment.

[^28]: Johannes Fankhauser, [“Taming the Delayed Choice Quantum Eraser”](https://arxiv.org/abs/1707.07884) (revised 2019). Analysis of the conditional statistics and the apparent retrocausal reading.

[^29]: Charles T. Sebens and Sean M. Carroll, [“Self-Locating Uncertainty and the Origin of Probability in Everettian Quantum Mechanics”](https://arxiv.org/abs/1405.7577), *The British Journal for the Philosophy of Science* 69, 25–74 (2018). A probability argument using epistemic separability.

[^30]: Adrian Kent, [“Does It Make Sense to Speak of Self-Locating Uncertainty in the Universal Wave Function? Remarks on Sebens and Carroll”](https://arxiv.org/abs/1408.1944), *Foundations of Physics* 45, 211–217 (2015). Critical response to the self-locating proposal.

[^31]: COGITATE Consortium and colleagues, [“Adversarial Testing of Global Neuronal Workspace and Integrated Information Theories of Consciousness”](https://pubmed.ncbi.nlm.nih.gov/40307561/), *Nature* 642, 133–142 (2025). Preregistered empirical comparison; DOI 10.1038/s41586-025-08888-1.
