# The Current Cosmology — Self-Contained Onboarding Packet

## What this packet is

This packet records the current state of a long-running attempt to connect five problems that are usually treated separately:

1. the structure of a maximally complete physical or formal reality;
2. the individuation of finite perspectives and persistent subjects within it;
3. the relation between formal structure and phenomenal awareness;
4. the emergence of valuers, agency, and normative constraint;
5. the reconstruction of theological language under an atemporal branching cosmology.

It is written to stand alone. The reader is not expected to possess the original papers, repository, conversation transcripts, or review documents. Definitions, central arguments, examples, limitations, and current conjectures are reproduced here. Original artifact names appear only to document intellectual lineage.

This is neither a finished theory nor a manifesto presenting every layer at equal confidence. It is a **status map**: what is formalized, what is a working architecture, what remains a metaphysical interpretation, what has been rejected, and where the missing bridges actually are.

Current through: **19 August 2026**.

## Fastest route through the packet

Choose an ingestion route below. Use [Volume V](05_INTELLECTUAL_LINEAGE_AND_PROVENANCE.md) when the theory's progression or a rejected branch matters, and [Volume VI](06_GLOSSARY_NOTATION_AND_CLAIM_STATUS.md) as the lookup reference.

### Token-efficient ingestion routes

- **Orientation only:** read this README. It contains the entire conceptual spine, strongest results, principal nonclaims, highly speculative extensions, and open problems in roughly 2,500 words.
- **Working competence:** read this README; Volume I §§2, 3.2, 7, 9–11, 15, and 17; Volume II §§2–6, 12, and 15; Volume III §§1–3, 5–7, 10, 13, and 16; and Volume IV §§2, 4–7, 9, 14, and 18. These selections include the control-asymmetry and open-problem material while omitting repeated provenance and speculative detail.
- **Branch-specific competence:** after this README, attach only Volume II for consciousness, Volume III for ethics/agency, or Volume IV for theology; consult Volume I when substrate or block-Everett assumptions become relevant.
- **Deep audit:** read all six volumes. Volume V can be postponed unless provenance, abandoned branches, or the reason for a caveat matters to the task.

For onboarding another language model, attach the README first. Add only the volume relevant to the immediate conversation, then add Volume V if the model begins repeating a rejected move or misreading the origin of a distinction.

## The cosmology in compressed form

The project began from an image combining Einstein and Everett:

> the universal wavefunction understood as a completed, atemporal, branching block.

The whole does not globally acquire one moment after another. Its internal histories nevertheless contain real orientation, succession, memory, anticipation, action, and consequence. Process is therefore not the opposite of completion. It is the form completion takes from inside a bounded trajectory.

The completed block is the generative cosmology, not an established result of the project's formal work. The lower-level machinery is more neutral. It begins with configurations, distinctions, relations, transformations, law sectors, and declared projections. These generate value-neutral continuation structures called **Alpha**.

A universal continuation structure does not automatically supply a creature, subject, or first-person viewpoint. A finite creature requires a perspective that distinguishes internal from external, accessible from inaccessible, and relevant from irrelevant. Perspective is constitutive rather than merely observational. A creature is formed non-excisively within the whole: individuation does not cut it free from the relations that sustain it.

Changing sections belong to one creature only if some world-supported identity relation binds them. The theological branch calls the inward identity-conferring continuity the **soul invariant**. The process branch describes the same general shape through **vorticality**: organizational identity regenerated through turnover, with the trajectory rather than an unchanging material set as bearer.

Neither strong identity nor vorticality proves consciousness. Formal structure can represent every behavior and report associated with awareness without demonstrating why any of it is experienced. The missing relation is marked by \(\kappa\), phenomenal coupling. This symbol identifies the explanatory gap; it does not close it.

In a branching universe, the theory distinguishes:

- **completed essence** — the full identity-compatible trajectory-space;
- **ontological actuality** — the trajectories instantiated in reality;
- **phenomenal actuality** — the branch-relative trajectory lived from within.

The original Everettian interpretation naturally makes all physical branches ontologically actual. It remains open whether each structurally adequate branch supports a branch-relative subject, whether one larger subject branches, or whether phenomenal coupling adds a stronger selection fact.

The project next asks which processes are **valuers**: systems for which differences among reachable continuations affect their own organization, policy, reconstruction, or recoverable continuity. Value is therefore not a property of raw state-space volume. It is value-for-a-valuer. A valuer need not be conscious, humanlike, or a moral patient, and the valuer boundary remains unresolved.

A valuer's **future field** is the structured continuation available relative to its state, actions, boundary, facts, and horizon. Raw entropy, branch count, complexity, and generic causal deformation do not measure value. The most promising operational hook is bounded irreversibility: which valuer-relevant distinctions are lost, whether they can be recovered, and whether a process actively maintains the conditions for its own correction and continuation.

**Omega** records compatibility among valuers or candidate continuation requirements. It retains the witnesses showing how coexistence is realized. It separates:

- **May compatibility** — some joint realization exists;
- **Robust compatibility** — one policy secures a joint realization across every declared environment.

Compatibility is genuinely polyadic. Every pair can be compatible while the triple is not; joint realization can exist while no single robust securing policy exists. Sometimes a plurality of policies is functionally required. These are structural results, not yet moral endorsements of plurality.

**Gradient Ethics** adds a conditional normative layer. It treats irreversible contraction of valuer-relevant continuation differently from reversible change, rejects favorable abstractions that erase the affected valuer or its correction capacity, and licenses action only through declared recovery, compatibility, and compensation gates. Its directive force depends on an explicit residual premise: affected valuers' endogenous continuation gradients count as reasons. The framework has not derived that premise from physics.

The moral branch stalls at three connected problems:

1. determining which processes possess **standing**, meaning legitimate normative inclusion or claims on others' action;
2. comparing or adjudicating incompatible valuers without installing an unearned global scalar;
3. constraining a dominant controller when power asymmetry destroys reciprocal enforcement.

The term **terminal solitude** names a nonrecoverable state in which no independently situated source of valuation remains. A singleton can preserve enormous internal complexity and still be terminally solitary if every apparent alternative is controlled by the same will. Yet the framework has not proved that every singleton is solitary, that control uniquely converges there, or that a dominant coordinator cannot preserve value better than unregulated competition.

The theological branch interprets completed actuality through a manifestational architecture:

\[
G^*
\xrightarrow{\mathcal L_\alpha}
D_\alpha
\xrightarrow{P_S}
(C_S,I_S)
\xleftrightarrow{\kappa_S}
\Phi_S
\xrightarrow{\sigma_S}
\gamma_S^\Phi.
\]

Here:

- \(G^*\) is God-as-such, named apophatically;
- \(\mathcal L_\alpha\) is logotic articulation under grammar \(\alpha\);
- \(D_\alpha\) is manifest actuality under that grammar;
- \(P_S\) constitutes a finite creaturely perspective;
- \(I_S\) is its identity or soul invariant;
- \(\kappa_S\) is the open phenomenal-coupling relation;
- \(\Phi_S\) is phenomenal presence;
- \(\sigma_S\) is the speculative relation between will and lived continuation;
- \(\gamma_S^\Phi\) is the lived trajectory.

Classical divine predicates are then reconstructed as finite perspectives on completed actuality. Pure act becomes absence of globally pending structural remainder; simplicity becomes articulation without assembly; omniscience becomes completed intelligibility rather than inference; providence becomes total relational order rather than forecasting and later intervention. These translations do not prove that completed actuality is conscious, intentional, loving, or good.

Formal completion is normatively neutral. A completed hell is no less formally complete than a completed heaven. The theological branch therefore attempts to locate goodness in relations among distinct agents: communion without erasure, compatible participation, love as communication of being and good, and justice as proportionate ordering. The categorical normative bridge remains open, as does the problem of horrific branches under full Everettian actuality.

## One architecture, several confidence levels

```text
APOPHATIC / METAPHYSICAL INTERPRETATION
God-as-such, logotic articulation, manifest actuality
                    |
                    v
GENERATIVE COSMOLOGY
completed block-Everett branching reality
                    |
                    v
FORMAL SUBSTRATE
distinction, relation, asymmetry, laws, configurations, projections
                    |
                    v
ALPHA
value-neutral continuation structures
                    |
                    v
EFFECTIVE ORGANISATIONS
perspectives, boundaries, identities, vortical processes
                    |
          +---------+---------+
          |                   |
          v                   v
PHENOMENAL PORT         VALUER / AGENT PORT
kappa, lived path       future fields, recovery, control
          |                   |
          +---------+---------+
                    v
OMEGA
witness-bearing May/Robust compatibility and obstruction
                    |
                    v
GRADIENT ETHICS
conditional licensing plus a signed normative premise
                    |
                    v
THEOLOGICAL / ESCHATOLOGICAL RECONSTRUCTION
providence, will, communion, judgment, heaven, hell
```

The arrows do not all have the same status. Some are definitions or formal constructions. Others are realization relations, metaphysical interpretations, or open bridges. Nothing in the diagram licenses reading the whole chain as one proof from physics to theology.

## What is solid

Relative to declared finite models, the project has established or carefully reproduced several important constraints:

- exact abstractions can preserve dynamics while erasing the directional property under investigation;
- feedback can generate functional non-invertibility from reversible primitive operations;
- pairwise compatibility can fail to determine joint compatibility;
- joint realizability can fail to imply robust joint securability;
- a plurality of local policies may cover a context even when no global policy exists;
- raw branching, entropy, rank, and marginal summaries can be matched while recovery or joint structure differs;
- recovery and irreversibility are indexed to fact language, repair actions, horizons, and presentations;
- favorable results in an abstraction need reflection checks before they can license conclusions about the concrete system.

These results constrain any later metaphysics or ethics. They do not establish that the modeled predicates are the unique correct descriptions of real agents, valuers, or worlds.

## What is architectural but not proved

- block Everett as the ontology of physical reality;
- creaturely perspective as the correct metaphysics of finite individuation;
- strong identity as a fundamental world-supported relation;
- soul invariant and vortical identity as related candidate accounts of persistence, without claiming they are identical;
- valuerhood as the substrate of all value;
- **lushness**—open-ended, nonduplicate, compatible differentiation in valuer-bearing continuation—as the relevant structure of good continuation;
- terminal solitude as **anti-value**, meaning destruction of the substrate admitting value-bearing continuation, rather than merely a structural endpoint;
- logotic manifestation as the right interpretation of completed reality;
- divine attributes as perspectives on that completion.

These are not casual metaphors. They organize the current research program. But their bridge to reality remains philosophical, empirical, or both.

## Highly speculative extensions

The following are candidate answers or mechanism-shapes with little or no direct formal or empirical support. They are not merely unfinished core definitions; the framework could abandon any of them while retaining its central architecture.

- awareness as a transformation of the formal **wake**—the describable processing dynamics left by world-signals passing through a vortical controller—into qualia;
- phenomenal steering among completed Everettian branches;
- a black-hole/white-hole complementarity for exterior and interior identity;
- a “wormhole” between formal possibility and **Being-as-such**, the still-undefined proposed actuality beyond formal exhaustiveness;
- consciousness emerging only in valuer-like organizations;
- divine consciousness, intention, omnibenevolence, and postmortem phenomenal continuity;
- a principled “divine retribution” license for containing robust **excisive controllers**, meaning controllers that capture, remove, or nonrecoverably foreclose independent valuers.

These conjectures are included because they expose candidate mechanism-shapes and missing constraints. They are not presented as results.

## The most important negative conclusions

The project currently rejects the following shortcuts:

- complexity, recursion, information integration, or formal completeness automatically produces consciousness;
- raw entropy, state count, branch count, or future volume measures value;
- any large deformation of a future field is morally significant in itself;
- a valuer is automatically an agent, conscious subject, or moral patient;
- persistence is automatically good;
- suffering is always bad or pleasure always good independent of structural context;
- compatibility is reducible to pairwise agreement;
- robust control creates moral authority;
- one scalar can be optimized without importing standing, aggregation, horizon, and presentation choices;
- formal completion entails goodness;
- the completed universal wavefunction is simply identical to a conscious personal God;
- black-hole or wormhole physics currently explains awareness.

## Open problems

These are required unanswered questions in the core architecture. Unlike the speculative extensions above, they cannot simply be removed without either weakening the framework's ambitions or supplying another answer.

The framework's next-order problems are tightly connected:

### 1. Valuer demarcation

What makes a bounded process a genuine locus of value rather than a passive deformer, externally authored instrument, parasite, or convenient projection? Irreversible maintenance and self-conditioning are promising markers, but the boundary is unsettled.

### 2. Phenomenal coupling

Which formal organizations, if any, are aware, and why? Does awareness emerge, bind fundamental phenomenality, express a dual aspect, or require an additional psychophysical law? The project can locate candidate carriers but cannot yet explain the spark.

### 3. Standing and aggregation

Why should the continuation of one valuer count as a reason for another? How should conflicting, overlapping, branching, or nested valuers be compared without treating identity as fungible or hiding the moral theory inside scalar weights?

### 4. Power asymmetry and authority

Reciprocal karma-like consequences lose enforcement power when one agent controls the system. A containment policy may be necessary, yet the classifier of “excisive” behavior can itself become sovereign and self-validating. The authority hole is therefore both theoretical and political.

### 5. Everettian identity and measure

How do branching subject identity, Born weight, responsibility, probability, and first-person actuality relate? Literal branch counting is ill-defined; normalized total measure is not a moral metric.

### 6. Divine consciousness and goodness

Completed order is not yet awareness, intention, or love. Under full Everett, horrific branches are actual rather than merely possible, sharpening rather than dissolving theodicy.

## Volume map

### [Volume I — Foundations and Cosmological Architecture](01_FOUNDATIONS_AND_COSMOLOGY.md)

The block-Everett generative model; epistemic starting point; formal, manifest, and total reality; distinction/relation/asymmetry; law sectors; projection; Alpha; perspective; completion and process; branching actuality; proof scope.

### [Volume II — Perspective, Identity, and Consciousness](02_PERSPECTIVE_IDENTITY_AND_CONSCIOUSNESS.md)

Creaturely boundary; weak and strong identity; soul invariant; vorticality; completed essence; ontological and phenomenal actuality; the hard problem; wake/awareness/qualia; panpsychism; black-hole, white-hole, and wormhole conjectures.

### [Volume III — Valuers, Agency, and Gradient Ethics](03_VALUERS_AGENCY_AND_ETHICS.md)

Valuer-indexed future fields; agency; irreversibility and recovery; compatibility; Omega; licensing; lushness; scalar failure modes; terminal solitude; control asymmetry; containment and the authority hole.

### [Volume IV — Theological Reconstruction](04_THEOLOGICAL_RECONSTRUCTION.md)

God-as-such; Logos; manifest divinity; perspective as creation; soul; pure act; simplicity; divine knowledge, power, providence, and will; goodness, love, justice, karma, judgment, heaven, hell, and apophatic limits.

### [Volume V — Intellectual Lineage and Provenance](05_INTELLECTUAL_LINEAGE_AND_PROVENANCE.md)

The logical progression from spaces of meaning through geometric intelligence, Gradient Ethics, the Omega laboratory, proto-teleology, recovery, contextuality, vorticality, multiscale Alpha, v6, theology, and the present consciousness work. Includes rejected and demoted branches.

### [Volume VI — Glossary, Notation, and Claim Status](06_GLOSSARY_NOTATION_AND_CLAIM_STATUS.md)

Project-specific definitions, symbol collisions, claim-status matrix, explicit nonclaims, and a quick lookup route.

## A final orientation for the reader

The project should not be understood as trying to force one intuition through formalism until the mathematics agrees. Its characteristic movement is the opposite: begin with an intuition, make it precise enough to fail, preserve the failure, and keep only the narrower structure that survives.

The result is neither simple nor complete. Actuality proved more complicated than the initial abstractions. But a surprising amount of the original shape survived:

- reality as a completed relational structure containing internal process;
- perspective as constitutive limitation;
- identity as a trajectory sustained through turnover;
- value as situated in valuers rather than raw possibility;
- compatibility as witness-bearing and irreducibly joint;
- irreversibility as a central asymmetry;
- theology as a perspective-conditioned interpretation of completion;
- consciousness and normativity as the two decisive unresolved bridges.

That is the present cosmology.
