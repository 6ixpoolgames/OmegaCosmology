# Generated runs

Write local run outputs here. They are ignored by Git by default. The baseline runner requires a new output directory and never overwrites the source results.

Retain a valuable completed result under research/results with its specification, code revision or digest, exact command and interpretation.
