"""Reserved package for new continuation-geometry probes.

No lushness definition is supplied by this scaffold.
"""
