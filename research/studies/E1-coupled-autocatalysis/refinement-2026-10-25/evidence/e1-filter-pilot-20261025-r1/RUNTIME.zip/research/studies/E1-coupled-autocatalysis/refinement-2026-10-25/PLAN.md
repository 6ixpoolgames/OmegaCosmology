# Local-history precision benchmark

25 October 2026, following the user's "Push and go next". This is a readout
refinement of E1, with no new physical law, policy choice or ethical prediction.
The pending platform/E1 work was pushed as 43167a8 before this step.

The question is whether deeper exact observation memory can resolve E1's small
donor-history effects at affordable cost. Start with its documented low-supply,
low-bill, slow-turnover AtoB versus local example. Keep both matched preparations,
all five horizons through T4096, cadence .25, both local coordinate projections,
and the known full-present conditioning. Preserve the original results.

Run memory2, then memory3 if feasible. Each law is inside a 240-second, 2-GiB,
16-MiB-output cap; at most two workers. Each batch is capped at 600 seconds and
64 MiB monitored output. Memory/workspace refusal or timeout is a method limit,
not a physical result. Do not decrease a scientific horizon to obtain a sign.
Record width, elapsed time and memory for every requested query. Verify the
unchanged full-history scores against the retained E1 cases and monotonic
tightening relative to memory1. Unresolved signs remain unresolved.

The analytic inequalities are evaluated in float64, not interval arithmetic.
Memory refinement preserves the physical state grain and changes the accuracy
of its hidden-history readout. It is not a new physical resolution corridor.
If deeper memory is too expensive or remains inconclusive, report that before
introducing a filtering/sampled estimator. Such an estimator needs an explicit
uncertainty contract and independent exact reference validation.

## Filtering pilot

The exact-memory jobs completed without changing physics. Memory2 took40.6s
for two laws; memory3 took276.5s. Memory2 only modestly tightened the documented
donor interval, motivating a separately typed statistical estimator rather than
an exponentially larger word query. The original memory1 results remain.

The [filter contract](../../../../formal/contracts/projected-filter-estimator-r1.md)
states its expectation identity, conditioning and separate approximate t versus
distribution-free uncertainty. The pilot plan checks both projections and both
preparations against exact full-prefix E1 entropies at .25/.5/1 time units using
8192 independent paired paths, seed2026102501. A separate64-path T256 job,
seed2026102502, profiles cost. Each case has240s/1GiB/1MiB output caps. Exact
short calibration is not proof of long-horizon statistical coverage.
