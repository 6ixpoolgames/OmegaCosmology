"""Sequential exact kernel schedule, preserving distributions and history totals.

Factories are called only after releasing the preceding kernel. The caller
certifies physical state alignment; this numerical primitive validates arrays.
"""

import time

import numpy as np

from .history import entropy, validate_distribution


def stream_schedule(phases, initial, checkpoints, *, score_history=True):
    """phases=(zero-argument kernel factory, positive step count).

    No reset at phase boundaries. Only requested endpoints are retained. The
    no-scoring mode supports physical/performance qualification before science.
    """
    phases = tuple(phases)
    checkpoints = set(checkpoints)
    if not phases or any(type(n) is not int or n <= 0 for _, n in phases):
        raise ValueError("Positive phase lengths required")
    total = sum(n for _, n in phases)
    if not checkpoints or any(
        type(n) is not int or not 0 <= n <= total for n in checkpoints
    ):
        raise ValueError("Checkpoints outside schedule")
    mu = validate_distribution(initial, len(initial)).copy()
    ell, step = 0.0, 0
    result = {}

    def capture():
        result[step] = {
            "endpoint": mu.copy(),
            "ell_bits": ell if score_history else None,
        }

    if 0 in checkpoints:
        capture()
    timings = []
    for factory, length in phases:
        kernel = factory()
        if (
            kernel.shape != (len(mu), len(mu))
            or not np.all(np.isfinite(kernel))
            or kernel.min() < 0
            or np.max(abs(kernel.sum(axis=1) - 1)) > 1e-10
        ):
            raise ValueError("Invalid aligned stochastic kernel")
        h = entropy(kernel, axis=1) if score_history else None
        start = time.perf_counter()
        for _ in range(length):
            if score_history:
                ell += float(mu @ h)
            mu = mu @ kernel
            step += 1
            if step in checkpoints:
                capture()
        timings.append(time.perf_counter() - start)
        del kernel, h
    return {
        "checkpoints": result,
        "propagation_seconds": timings,
        "scored": score_history,
    }
