"""Bounded physical moment matching, with no access to the history score."""

from itertools import product

import numpy as np
from scipy.optimize import least_squares


def match_physical_moments(
    evaluate, target, bounds, *, max_evaluations=24, tolerance=0.001
):
    """Probe then fit in a positive parameter box; report a failed match honestly.

    evaluate receives only parameters and returns the named physical moments.
    Bounds constrain the physical family, not a post-hoc score correction.
    Every evaluated point is retained. No inference of global infeasibility.
    """
    names = tuple(bounds)
    moments = tuple(target)
    if (
        not names
        or len(names) > 3
        or not moments
        or type(max_evaluations) is not int
        or max_evaluations < 1
        or not np.isfinite(tolerance)
        or tolerance <= 0
        or any(not np.isfinite(v) for v in target.values())
        or any(
            len(b) != 2 or not 0 < b[0] < b[1] or not np.isfinite(b[1])
            for b in bounds.values()
        )
    ):
        raise ValueError(
            "Finite targets, positive bounded parameters and search budget required"
        )
    lo = np.log([bounds[k][0] for k in names])
    hi = np.log([bounds[k][1] for k in names])
    scales = np.maximum(1.0, np.abs([target[k] for k in moments]))
    rows, cache = [], {}

    def evaluate_at(log_values):
        parameters = {k: float(np.exp(x)) for k, x in zip(names, log_values)}
        key = tuple(parameters.values())
        if key not in cache:
            values = evaluate(parameters)
            if set(values) != set(moments) or any(
                not np.isfinite(v) for v in values.values()
            ):
                raise ValueError(
                    "Moment evaluator returned different/nonfinite quantities"
                )
            residual = (np.array([values[k] - target[k] for k in moments])) / scales
            entry = {
                "parameters": parameters,
                "moments": values,
                "scaled_residuals": dict(zip(moments, residual.tolist())),
            }
            rows.append(entry)
            cache[key] = residual
        return cache[key]

    for point in product((0.0, 0.5, 1.0), repeat=len(names)):
        evaluate_at(lo + np.array(point) * (hi - lo))
    best = min(rows, key=lambda r: sum(v * v for v in r["scaled_residuals"].values()))
    # SciPy's max_nfev excludes finite-difference calls. Also enforce a literal
    # moment-evaluator budget for the fitted search, including those calls.
    probe_count = len(rows)

    class BudgetReached(Exception):
        pass

    def objective(x):
        key = tuple(float(np.exp(v)) for v in x)
        if key not in cache and len(rows) - probe_count >= max_evaluations:
            raise BudgetReached
        return evaluate_at(x)

    reason = "optimizer_completed"
    try:
        least_squares(
            objective,
            np.log([best["parameters"][k] for k in names]),
            bounds=(lo, hi),
            max_nfev=max_evaluations,
            xtol=1e-9,
            ftol=1e-9,
            gtol=1e-9,
        )
    except BudgetReached:
        reason = "literal_evaluation_budget_reached"
    best = min(rows, key=lambda r: sum(v * v for v in r["scaled_residuals"].values()))
    matched = max(abs(v) for v in best["scaled_residuals"].values()) <= tolerance
    return {
        "status": "matched" if matched else "not_matched_in_bounded_search",
        "target": target,
        "bounds": bounds,
        "scale": dict(zip(moments, scales.tolist())),
        "tolerance": tolerance,
        "best": best,
        "evaluations": rows,
        "probe_evaluations": probe_count,
        "fit_evaluation_budget": max_evaluations,
        "termination": reason,
        "scope": "Physical moment search only; no lushness objective, no all-path match or global infeasibility certificate",
    }
